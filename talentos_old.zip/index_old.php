<?php
/**
 * Inicio
 *
 * Inicio del Sistema de Informacion Web del Plan Talentos
 *
 * @author Carlos Andres Mercado <carlos00714@gmail.com>
 * @version 2.0
 * @copyright DINTEV
 */
  session_start();

  /**
  * Informacion de las rutas de las carpetas principales del Sistema
  */
  require_once './Config/paths.php';
  /**
   * Definicion de algunas constantes usadas dentro del Sistema
   */
  require_once CARPETA_CONFIG. 'constants.php';
  /**
   * Funciones de ayuda para el Sistema
   */
  require_once CARPETA_LIBS.'AppLoader.class.php';
  
  require_once CARPETA_CONFIG. 'autoload.php';
  
  $appDispatcher = new AppDispatcher();
  $appDispatcher->dispatch();
  return false;
  
?>
