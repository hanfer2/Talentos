<?php

/**
*pasa el nombre de todos los archivos que  necesitan
*ser cargadosa,al llamar el index.php. a los metodos de la clase AppLoader  
*/ 
  
 /**
*HELPERS 
*/

   AppLoader::load_helper('_');
   AppLoader::load_helper('String');
   AppLoader::load_helper('Number');
   AppLoader::load_helper('Time');
   AppLoader::load_helper('Array');
   AppLoader::load_helper('Session');
   AppLoader::load_helper('Sql');
   AppLoader::load_helper('Html');
   AppLoader::load_helper('Route');

    /**
*LIBS cargas las librerias
*/
    
   AppLoader::load('DB');
   AppLoader::load('CSV');
   AppLoader::load('JSON');
   AppLoader::load('Logger');
   AppLoader::load('Markdown');
   AppLoader::load('MenuFactory');
   

 /**
*llama la vista a mostrar, pagina de inicio de la aplicacion talentos
*/
   AppLoader::load_file(CARPETA_VISTAS.'Vista');
   AppLoader::load_model('TBaseModel');
   
   AppLoader::load('ModuleConfig');
   AppLoader::load('AppDispatcher');
?>
