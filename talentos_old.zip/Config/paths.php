<?php

 /**
  * Almacena las rutas de las carpetas principales del Sistema.
  */
  error_reporting(E_ALL ^ E_NOTICE);
	define('WIN', preg_match('/WIN/i', $_SERVER['HTTP_USER_AGENT']));
	define('DS','/');

  /**
   * Define la ruta de la carpeta ROOT
   */
  define('CARPETA_ROOT','.' . DS);

  /**
   * Define la rutas de las carpetas principales
   */
  define('CARPETA_CONTROLADORES',CARPETA_ROOT  . 'Controllers' . DS);
  define('CARPETA_HELPERS',CARPETA_ROOT  . 'Helpers' . DS);
  define('CARPETA_VISTAS',CARPETA_ROOT  . 'Views' . DS);
  define('CARPETA_MODELOS', CARPETA_ROOT  . 'Models' . DS);
  define('CARPETA_LIBS',CARPETA_ROOT  . 'Libs' . DS);
  define('CARPETA_CONFIG',CARPETA_ROOT  . 'Config' . DS);

  define('CARPETA_MODELOS_EXTRAS',CARPETA_MODELOS.'Extra' . DS);
  define('CARPETA_MODELOS_INFORMES',CARPETA_MODELOS.'Reports' . DS);

  define('CARPETA_LAYOUTS', CARPETA_VISTAS.'_layouts' . DS);
  define('CARPETA_PUBLIC', CARPETA_VISTAS.'_public' . DS);
  define('CARPETA_IMGS', CARPETA_PUBLIC.'img' . DS);
  define('CARPETA_CSS', CARPETA_PUBLIC.'css' . DS);
  define('CARPETA_JS',CARPETA_PUBLIC.'js' . DS);

  define('INDEX_FILE', CARPETA_ROOT . 'index.php');
  

?>
