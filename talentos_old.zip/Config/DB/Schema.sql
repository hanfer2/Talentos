--
-- PostgreSQL database dump
--

SET client_encoding = 'LATIN1';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET search_path = public, pg_catalog;

--
-- Name: plpgsql_call_handler(); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION plpgsql_call_handler() RETURNS language_handler
    AS '/usr/local/pgsql/lib/plpgsql.so', 'plpgsql_call_handler'
    LANGUAGE c;


ALTER FUNCTION public.plpgsql_call_handler() OWNER TO dintev;

--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: public; Owner: 
--

CREATE PROCEDURAL LANGUAGE plpgsql HANDLER plpgsql_call_handler;


--
-- Name: comuna_predominante_por_curso(integer); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION comuna_predominante_por_curso(integer) RETURNS record
    AS $_$SELECT comuna::integer, CAST(count(*) AS integer ) AS cantidad
FROM a_persona INNER JOIN v_estudiantes_grupos USING (cod_interno)
WHERE a_persona.cod_estado = 11 AND cod_grupo = $1 
GROUP BY comuna
ORDER BY cantidad DESC$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.comuna_predominante_por_curso(integer) OWNER TO dintev;

--
-- Name: edad(date); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION edad(date) RETURNS double precision
    AS $_$SELECT extract(year FROM age($1))$_$
    LANGUAGE sql STABLE;


ALTER FUNCTION public.edad(date) OWNER TO dintev;

SET default_tablespace = '';

SET default_with_oids = true;

--
-- Name: a_persona; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_persona (
    cod_interno integer NOT NULL,
    cod_tipo_per integer NOT NULL,
    cod_estud character(9),
    cod_tipo_ced integer NOT NULL,
    cedula character varying(13) NOT NULL,
    cod_expedida character varying(10) NOT NULL,
    apellidos character varying(30) NOT NULL,
    nombres character varying(30) NOT NULL,
    genero character(1) NOT NULL,
    direccion character varying(80),
    cod_ciudad character varying(10),
    telefono character varying(30),
    direccion_alt character varying(50),
    barrio_alt character varying(25),
    telefono_alt character varying(50),
    cod_estado_civil integer NOT NULL,
    email character varying(100),
    email_2 character varying(100),
    nombre_acudiente character varying(50),
    tel_celular character varying(15),
    libreta_militar character(13),
    distrito_lib_mil character varying(2),
    clase_lib_mil character(1),
    cod_oficio integer,
    fecha_nacimiento date,
    cod_lugar_nacimiento character varying(10),
    cod_estado integer DEFAULT 11 NOT NULL,
    estrato numeric(1,0),
    fecha_ingreso date DEFAULT now(),
    departamento character varying(100),
    cod_tipo_monitor character(2),
    comuna integer,
    tel2_persona_res character varying(15),
    barrio integer,
    cod_discapacidad smallint DEFAULT 0,
    cod_etnia smallint DEFAULT 0,
    hijos smallint DEFAULT 0 NOT NULL,
    CONSTRAINT a_personas_genero_valido CHECK (((genero = 'M'::bpchar) OR (genero = 'F'::bpchar))),
    CONSTRAINT ch_a_persona_estrato CHECK (((estrato >= (1)::numeric) AND (estrato <= (6)::numeric)))
);


ALTER TABLE public.a_persona OWNER TO dintev;

--
-- Name: TABLE a_persona; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_persona IS 'Informaci�n de toda persona dentro del sistema';


--
-- Name: COLUMN a_persona.cod_interno; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_interno IS 'codigo interno del usuario';


--
-- Name: COLUMN a_persona.cod_tipo_per; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_tipo_per IS 'C�digo del tipo de persona: : 1 Estudiante, 2 Docente, 3 Monitor, 4 Administrador';


--
-- Name: COLUMN a_persona.cod_estud; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_estud IS 'C�digo de estudiante, si es estudiante';


--
-- Name: COLUMN a_persona.cod_tipo_ced; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_tipo_ced IS 'C�digo del tipo de documento de identidad';


--
-- Name: COLUMN a_persona.cedula; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cedula IS 'N�mero del documento de identidad';


--
-- Name: COLUMN a_persona.cod_expedida; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_expedida IS 'C�digo de la ciudad donde fue expedido el documento de identidad';


--
-- Name: COLUMN a_persona.genero; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.genero IS 'G�nero: M Masculino o F Femenino';


--
-- Name: COLUMN a_persona.cod_ciudad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_ciudad IS 'C�digo de la ciudad de residencia';


--
-- Name: COLUMN a_persona.telefono; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.telefono IS 'N�mero de telefono fijo';


--
-- Name: COLUMN a_persona.direccion_alt; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.direccion_alt IS 'Direcci�n del acudiente';


--
-- Name: COLUMN a_persona.barrio_alt; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.barrio_alt IS 'Barrio donde vive el acudiente';


--
-- Name: COLUMN a_persona.telefono_alt; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.telefono_alt IS 'N�mero de tel�fono fijo o celular del acudiente';


--
-- Name: COLUMN a_persona.cod_estado_civil; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_estado_civil IS 'C�digo del tipo de estado civil, ejemplos: 1 Soltero, 2 Casado, etc.';


--
-- Name: COLUMN a_persona.email; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.email IS 'Correo electr�nico';


--
-- Name: COLUMN a_persona.email_2; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.email_2 IS 'Correo electr�nico alternativo';


--
-- Name: COLUMN a_persona.nombre_acudiente; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.nombre_acudiente IS 'Nombre del acudiente';


--
-- Name: COLUMN a_persona.tel_celular; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.tel_celular IS 'N�mero de tel�fono celular';


--
-- Name: COLUMN a_persona.libreta_militar; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.libreta_militar IS 'N�mero de la libreta militar';


--
-- Name: COLUMN a_persona.distrito_lib_mil; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.distrito_lib_mil IS 'Distrito de la libreta militar';


--
-- Name: COLUMN a_persona.clase_lib_mil; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.clase_lib_mil IS 'Clase de la libreta miltar';


--
-- Name: COLUMN a_persona.cod_oficio; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_oficio IS 'C�digo del oficio desempe�ado, ejemplos: 1 Ama de casa, 2 Aseador, 3 Aux. oficina, etc.';


--
-- Name: COLUMN a_persona.cod_lugar_nacimiento; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_lugar_nacimiento IS 'C�digo de la ciudad de nacimiento';


--
-- Name: COLUMN a_persona.cod_estado; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_estado IS 'C�digo del estado en que se encuentra la person, ejemplos: 11 Activo, 12 Inactivo, etc.';


--
-- Name: COLUMN a_persona.estrato; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.estrato IS 'Estrato del barrio de residencia';


--
-- Name: COLUMN a_persona.fecha_ingreso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.fecha_ingreso IS 'Fecha de ingreso al sistema';


--
-- Name: COLUMN a_persona.cod_tipo_monitor; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_tipo_monitor IS 'Codigo para del Monitor Administrativo';


--
-- Name: COLUMN a_persona.comuna; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.comuna IS 'Las comunas 21 y 22, se representa como 13.5 y 17.5 respectivameente';


--
-- Name: COLUMN a_persona.tel2_persona_res; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.tel2_persona_res IS '???';


--
-- Name: COLUMN a_persona.barrio; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.barrio IS 'C�digo del barrio de residencia';


--
-- Name: COLUMN a_persona.cod_discapacidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.cod_discapacidad IS 'codigo de la discapacidad del usuario';


--
-- Name: COLUMN a_persona.hijos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_persona.hijos IS 'cantidad de hijos';


--
-- Name: fullname(a_persona); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION fullname(persona a_persona) RETURNS character varying
    AS $_$SELECT ($1.apellidos::text || ', '::text) || $1.nombres::text;$_$
    LANGUAGE sql STABLE;


ALTER FUNCTION public.fullname(persona a_persona) OWNER TO dintev;

--
-- Name: fullname(a_persona, character varying); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION fullname(a_persona, character varying) RETURNS character varying
    AS $_$  SELECT $1.apellidos::text || $2 || $1.nombres::text;$_$
    LANGUAGE sql STABLE;


ALTER FUNCTION public.fullname(a_persona, character varying) OWNER TO dintev;

--
-- Name: v_estudiantes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes AS
    SELECT a_persona.cod_estado, a_persona.cod_interno, a_persona.tel_celular, a_persona.email, a_persona.cedula, a_persona.nombres, a_persona.apellidos FROM a_persona WHERE (a_persona.cod_tipo_per = 1);


ALTER TABLE public.v_estudiantes OWNER TO dintev;

--
-- Name: VIEW v_estudiantes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes IS 'Muestra informaci�n b�sica de los estudiantes del Plan Talentos';


--
-- Name: fullname(v_estudiantes, character varying); Type: FUNCTION; Schema: public; Owner: dintev
--

CREATE FUNCTION fullname(v_estudiantes, separator character varying) RETURNS character varying
    AS $_$SELECT $1.apellidos::text || $2 || $1.nombres::text;$_$
    LANGUAGE sql STABLE;


ALTER FUNCTION public.fullname(v_estudiantes, separator character varying) OWNER TO dintev;

--
-- Name: a_activi_cur; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_activi_cur (
    consecutivo integer NOT NULL,
    cod_periodo integer NOT NULL,
    cod_curso character(6) NOT NULL,
    cod_actividad integer NOT NULL,
    comentario character varying(60),
    fecha date,
    hora character varying,
    lugar character varying,
    confirmado character(2),
    cod_grupo integer NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE public.a_activi_cur OWNER TO dintev;

--
-- Name: TABLE a_activi_cur; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_activi_cur IS 'Actividades de cada curso';


--
-- Name: COLUMN a_activi_cur.cod_actividad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.cod_actividad IS 'Actividad a desarrollar';


--
-- Name: COLUMN a_activi_cur.comentario; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.comentario IS 'Observaciones sobre la actividad';


--
-- Name: COLUMN a_activi_cur.fecha; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.fecha IS 'Fecha de la actividad';


--
-- Name: COLUMN a_activi_cur.hora; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.hora IS 'Hora de la actividad';


--
-- Name: COLUMN a_activi_cur.lugar; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.lugar IS 'Lugar de la actividad';


--
-- Name: COLUMN a_activi_cur.confirmado; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.confirmado IS 'SI esta confirmada o NO esta confirmada la actividad';


--
-- Name: COLUMN a_activi_cur.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_activi_cur.nombre IS 'Nombre dado a la actividad';


--
-- Name: a_asistencia; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_asistencia (
    codigo integer DEFAULT nextval('public.a_asistencia_codigo_seq'::text) NOT NULL,
    cod_curso character(6) NOT NULL,
    cod_grupo integer NOT NULL,
    cod_periodo integer NOT NULL,
    fecha_clase date NOT NULL,
    cod_interno integer NOT NULL,
    observaciones text,
    fecha_hora_registro timestamp without time zone DEFAULT ('now'::text)::timestamp(0) with time zone NOT NULL,
    fecha_hora_update timestamp without time zone DEFAULT ('now'::text)::timestamp(0) with time zone NOT NULL,
    cod_interno_update integer
);


ALTER TABLE public.a_asistencia OWNER TO dintev;

--
-- Name: TABLE a_asistencia; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_asistencia IS 'Reporta la asistencia para cada curso';


--
-- Name: COLUMN a_asistencia.fecha_hora_update; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_asistencia.fecha_hora_update IS 'fecha-hora de la ultima actualizacion';


--
-- Name: COLUMN a_asistencia.cod_interno_update; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_asistencia.cod_interno_update IS 'C�digo Interno de quien hace la actualizaci�n';


--
-- Name: a_asistencia_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_asistencia_codigo_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_asistencia_codigo_seq OWNER TO dintev;

--
-- Name: a_barrio_bar_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_barrio_bar_codigo_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_barrio_bar_codigo_seq OWNER TO dintev;

--
-- Name: a_bloqueados; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_bloqueados (
    cod_interno integer,
    motivo character varying(4),
    fecha date DEFAULT ('now'::text)::date,
    updated_by integer,
    authorized_by character varying(30)
);


ALTER TABLE public.a_bloqueados OWNER TO dintev;

--
-- Name: TABLE a_bloqueados; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_bloqueados IS 'Personas que ya no pertenecen al sistema';


--
-- Name: COLUMN a_bloqueados.motivo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_bloqueados.motivo IS 'Motivo por el cual la persona sale del sistema';


--
-- Name: COLUMN a_bloqueados.fecha; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_bloqueados.fecha IS 'Fecha del bloqueo';


--
-- Name: COLUMN a_bloqueados.updated_by; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_bloqueados.updated_by IS 'Actualizado Por';


--
-- Name: COLUMN a_bloqueados.authorized_by; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_bloqueados.authorized_by IS 'Nombre de quien autorizo esta operacion';


--
-- Name: a_componentes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_componentes (
    codigo character(6) NOT NULL,
    nombre character varying(100) NOT NULL,
    modalidad character varying(50)
);


ALTER TABLE public.a_componentes OWNER TO dintev;

--
-- Name: TABLE a_componentes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_componentes IS 'Componentes (materias) ';


--
-- Name: COLUMN a_componentes.codigo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_componentes.codigo IS 'C�digo del componente';


--
-- Name: COLUMN a_componentes.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_componentes.nombre IS 'Nombre del componente';


--
-- Name: COLUMN a_componentes.modalidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_componentes.modalidad IS 'Campo al que pertenece el componente, ejemplos: acad�mico, vida universitaria, etc.';


--
-- Name: a_detalle_asistencia; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_detalle_asistencia (
    cod_interno integer NOT NULL,
    cod_asistencia integer NOT NULL,
    asiste character(2) NOT NULL,
    observacion text,
    cod_periodo integer,
    CONSTRAINT check_asiste CHECK (((asiste = 'SI'::bpchar) OR (asiste = 'NO'::bpchar)))
);


ALTER TABLE public.a_detalle_asistencia OWNER TO dintev;

--
-- Name: COLUMN a_detalle_asistencia.asiste; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_detalle_asistencia.asiste IS 'valores "SI" o "NO"';


--
-- Name: a_empresa_envios_id_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_empresa_envios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_empresa_envios_id_seq OWNER TO dintev;

--
-- Name: a_estados; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_estados (
    codigo integer NOT NULL,
    nombre character varying(25) NOT NULL
);


ALTER TABLE public.a_estados OWNER TO dintev;

--
-- Name: TABLE a_estados; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_estados IS 'Estado de la persona dentro del sistema';


--
-- Name: a_estud_curso; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_estud_curso (
    codigo integer NOT NULL,
    cod_interno integer NOT NULL,
    cod_estado integer DEFAULT 1 NOT NULL,
    cod_curso character(6) NOT NULL,
    certificado character(2) DEFAULT 'SI'::bpchar NOT NULL,
    definitiva numeric(3,2),
    definitiva_txt character(1),
    cod_profesor integer,
    prorroga date,
    cod_periodo integer NOT NULL,
    cod_nivel integer DEFAULT 1 NOT NULL,
    cod_nodo integer DEFAULT 1 NOT NULL,
    material character varying(40),
    fecha_cancelado date,
    fecha_prorroga date,
    fecha_env_mate date,
    usu_env_mate character varying(30),
    fecha_matriacad date,
    usu_matriacad character varying(20),
    conse_porcentaje integer NOT NULL,
    fecha_terminado date,
    cod_grupo integer NOT NULL
);


ALTER TABLE public.a_estud_curso OWNER TO dintev;

--
-- Name: TABLE a_estud_curso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_estud_curso IS 'Relaciona un estudiante con un curso';


--
-- Name: pe_estudiantes_universidades; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_estudiantes_universidades (
    codigo serial NOT NULL,
    cod_interno integer NOT NULL,
    cod_universidad integer NOT NULL,
    cod_carrera integer NOT NULL,
    fecha_ingreso date,
    "nSemestres" integer
);


ALTER TABLE public.pe_estudiantes_universidades OWNER TO dintev;

--
-- Name: TABLE pe_estudiantes_universidades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_estudiantes_universidades IS 'TABLA DE INGRESOS A EDUCACION SUPERIOR';


--
-- Name: COLUMN pe_estudiantes_universidades.cod_interno; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_estudiantes_universidades.cod_interno IS 'C�digo del estudiante';


--
-- Name: COLUMN pe_estudiantes_universidades.cod_universidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_estudiantes_universidades.cod_universidad IS 'C�digo de la Universidad';


--
-- Name: COLUMN pe_estudiantes_universidades.cod_carrera; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_estudiantes_universidades.cod_carrera IS 'C�digo de la carrera';


--
-- Name: COLUMN pe_estudiantes_universidades."nSemestres"; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_estudiantes_universidades."nSemestres" IS 'Numero de Semestres de la Carrera';


--
-- Name: a_estudiantes_grupos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_estudiantes_grupos (
    codigo serial NOT NULL,
    cod_interno integer NOT NULL,
    cod_grupo integer NOT NULL,
    fecha_ingreso date DEFAULT now() NOT NULL,
    updated_by integer
);


ALTER TABLE public.a_estudiantes_grupos OWNER TO dintev;

--
-- Name: TABLE a_estudiantes_grupos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_estudiantes_grupos IS 'Relaciona un estudiante con el curso al que pertenece';


--
-- Name: COLUMN a_estudiantes_grupos.cod_grupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_grupos.cod_grupo IS 'C�digo del curso al que pertenece el estudiante';


--
-- Name: COLUMN a_estudiantes_grupos.fecha_ingreso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_grupos.fecha_ingreso IS 'Fecha en que ingreso al curso';


--
-- Name: COLUMN a_estudiantes_grupos.updated_by; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_grupos.updated_by IS 'Actualizado Por';


--
-- Name: a_estudiantes_icfes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_estudiantes_icfes (
    cod_interno integer NOT NULL,
    num_registro_icfes character varying(25) NOT NULL,
    lenguaje numeric(5,2),
    matematica numeric(5,2),
    geografia numeric(5,2),
    historia numeric(5,2),
    sociales numeric(5,2),
    filosofia numeric(5,2),
    biologia numeric(5,2),
    quimica numeric(5,2),
    fisica numeric(5,2),
    idioma numeric(5,2),
    cod_idioma integer,
    interdisciplinar numeric(5,2),
    cod_interdisciplinar integer,
    tipo integer NOT NULL,
    CONSTRAINT chk_icfes_nota_biologia CHECK (((biologia >= (0)::numeric) AND (biologia <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_filosofia CHECK (((filosofia >= (0)::numeric) AND (filosofia <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_fisica CHECK (((fisica >= (0)::numeric) AND (fisica <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_idioma CHECK (((idioma >= (0)::numeric) AND (idioma <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_interdisc CHECK (((interdisciplinar >= (0)::numeric) AND (interdisciplinar <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_lenguaje CHECK (((lenguaje >= (0)::numeric) AND (lenguaje <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_matem CHECK (((matematica >= (0)::numeric) AND (matematica <= (100)::numeric))),
    CONSTRAINT chk_icfes_nota_quimica CHECK (((quimica >= (0)::numeric) AND (quimica <= (100)::numeric)))
);


ALTER TABLE public.a_estudiantes_icfes OWNER TO dintev;

--
-- Name: TABLE a_estudiantes_icfes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_estudiantes_icfes IS 'Relaciona un estudiante con los datos de su ICFES';


--
-- Name: COLUMN a_estudiantes_icfes.geografia; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.geografia IS 'para icfes antiguos';


--
-- Name: COLUMN a_estudiantes_icfes.historia; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.historia IS 'para icfes antiguos';


--
-- Name: COLUMN a_estudiantes_icfes.sociales; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.sociales IS 'para icfes recientes';


--
-- Name: COLUMN a_estudiantes_icfes.biologia; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.biologia IS ' ';


--
-- Name: COLUMN a_estudiantes_icfes.quimica; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.quimica IS ' ';


--
-- Name: COLUMN a_estudiantes_icfes.cod_idioma; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.cod_idioma IS 'C�digo del idioma presentado, ejemplos: 5 para Ingles, 3 para Alem�n, etc.';


--
-- Name: COLUMN a_estudiantes_icfes.cod_interdisciplinar; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.cod_interdisciplinar IS 'C�digo de la interdisciplinar, ejemplos: 1 Violencia y sociedad, 3 Medio ambiente, etc.';


--
-- Name: COLUMN a_estudiantes_icfes.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_estudiantes_icfes.tipo IS 'Tipo de ICFES presentado: oficial, simulacro, etc.';


--
-- Name: a_grupos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_grupos (
    codigo integer NOT NULL,
    cod_director integer,
    grupo character(1) NOT NULL,
    subgrupo integer NOT NULL,
    cod_programa character varying(4) NOT NULL,
    tipo character varying(2)
);


ALTER TABLE public.a_grupos OWNER TO dintev;

--
-- Name: TABLE a_grupos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_grupos IS 'Los cursos (grupos) del plan talentos';


--
-- Name: COLUMN a_grupos.cod_director; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_grupos.cod_director IS 'Codigo del Director del Grupo';


--
-- Name: COLUMN a_grupos.grupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_grupos.grupo IS 'Letra del Grupo';


--
-- Name: COLUMN a_grupos.subgrupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_grupos.subgrupo IS 'N�mero del curso';


--
-- Name: COLUMN a_grupos.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_grupos.tipo IS 'NULL=>Academico;TF=>Taller Formativo';


--
-- Name: a_horario; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_horario (
    codigo integer NOT NULL,
    dia_semana integer NOT NULL,
    hora_inicio time without time zone NOT NULL,
    hora_final time without time zone NOT NULL,
    salon character varying(30),
    edificio character varying(30),
    cod_nodo integer,
    fecha_inicio date NOT NULL,
    fecha_final date NOT NULL,
    cod_periodo integer NOT NULL,
    cod_curso character(6) NOT NULL,
    cod_grupo_mayor character(1) NOT NULL,
    cod_grupo_menor integer,
    CONSTRAINT fcheck_cod_grupo_mayor CHECK (((((((cod_grupo_mayor = 'A'::bpchar) OR (cod_grupo_mayor = 'B'::bpchar)) OR (cod_grupo_mayor = 'C'::bpchar)) OR (cod_grupo_mayor = 'D'::bpchar)) OR (cod_grupo_mayor = 'T'::bpchar)) OR (cod_grupo_mayor = 'V'::bpchar)))
);


ALTER TABLE public.a_horario OWNER TO dintev;

--
-- Name: TABLE a_horario; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_horario IS 'Horario de los cursos ofrecidos';


--
-- Name: COLUMN a_horario.dia_semana; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_horario.dia_semana IS 'de 1 a 6 correspondiente al intervalo Lunes a Sabado';


--
-- Name: a_horario_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_horario_codigo_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_horario_codigo_seq OWNER TO dintev;

--
-- Name: a_observaciones_estud_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_observaciones_estud_codigo_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_observaciones_estud_codigo_seq OWNER TO dintev;

--
-- Name: a_periodo; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_periodo (
    codigo integer NOT NULL,
    nombre character varying(25) NOT NULL,
    descripcion character varying(30),
    fecha_inicio date,
    fecha_final date,
    total_dias integer,
    tipo character varying(20) DEFAULT 'ACAD�MICO'::character varying,
    CONSTRAINT a_periodo_fecha_final_mayor CHECK ((fecha_final > fecha_inicio))
);


ALTER TABLE public.a_periodo OWNER TO dintev;

--
-- Name: COLUMN a_periodo.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_periodo.tipo IS 'ACADEMICO/INTERSEMESTRAL';


--
-- Name: pr_periodos_programas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pr_periodos_programas (
    codigo serial NOT NULL,
    cod_programa character varying(4) NOT NULL,
    cod_periodo integer NOT NULL
);


ALTER TABLE public.pr_periodos_programas OWNER TO dintev;

--
-- Name: TABLE pr_periodos_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pr_periodos_programas IS 'Relaciona un periodo con un programa en especial';


--
-- Name: a_persona_cod_interno_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_persona_cod_interno_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_persona_cod_interno_seq OWNER TO dintev;

--
-- Name: a_programas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE a_programas (
    codigo character varying(5) NOT NULL,
    nombre character varying(150) NOT NULL,
    cod_director integer,
    fecha_inicio_1 date,
    fecha_cierre_1 date,
    fecha_inicio_2 date,
    fecha_cierre_2 date,
    CONSTRAINT a_programa_fecha_fin_mayor CHECK ((fecha_cierre_1 > fecha_inicio_1))
);


ALTER TABLE public.a_programas OWNER TO dintev;

--
-- Name: TABLE a_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE a_programas IS 'Representa las diferentes promociones del Plan Talentos';


--
-- Name: COLUMN a_programas.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.nombre IS 'Nombre de la promoci�n';


--
-- Name: COLUMN a_programas.cod_director; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.cod_director IS 'C�digo del director';


--
-- Name: COLUMN a_programas.fecha_inicio_1; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.fecha_inicio_1 IS 'Fecha de inicio del primer semestre';


--
-- Name: COLUMN a_programas.fecha_cierre_1; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.fecha_cierre_1 IS 'Fecha de cierre del primer semestre';


--
-- Name: COLUMN a_programas.fecha_inicio_2; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.fecha_inicio_2 IS 'Fecha de inicio del segundo semestre';


--
-- Name: COLUMN a_programas.fecha_cierre_2; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN a_programas.fecha_cierre_2 IS 'Fecha de finalizaci�n';


--
-- Name: a_programas_educacion_superior_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_programas_educacion_superior_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_programas_educacion_superior_seq OWNER TO dintev;

--
-- Name: a_salida_inventario_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_salida_inventario_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_salida_inventario_codigo_seq OWNER TO dintev;

--
-- Name: a_tipo_icfes_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_tipo_icfes_codigo_seq
    START WITH 5
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 5;


ALTER TABLE public.a_tipo_icfes_codigo_seq OWNER TO dintev;

--
-- Name: a_universidades_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE a_universidades_codigo_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.a_universidades_codigo_seq OWNER TO dintev;

--
-- Name: cu_areas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_areas (
    codigo character(3) NOT NULL,
    nombre character varying(80) NOT NULL
);


ALTER TABLE public.cu_areas OWNER TO dintev;

--
-- Name: TABLE cu_areas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_areas IS 'Categoria gen�rica de un curso y su descripcion';


--
-- Name: cu_asistencias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_asistencias (
    codigo character varying(20) NOT NULL,
    cod_clase character varying(15) NOT NULL,
    cod_interno integer NOT NULL,
    asiste boolean DEFAULT true NOT NULL,
    cod_motivo smallint
);


ALTER TABLE public.cu_asistencias OWNER TO dintev;

--
-- Name: TABLE cu_asistencias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_asistencias IS 'Relaciona Asistencias por Clase';


--
-- Name: COLUMN cu_asistencias.codigo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_asistencias.codigo IS 'cod_clase+''-''+cod_interno';


--
-- Name: COLUMN cu_asistencias.cod_motivo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_asistencias.cod_motivo IS 'codigo del motivo de inasistencia';


--
-- Name: cu_categorias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_categorias (
    cod_area character varying(3) NOT NULL,
    cod_ciclo character varying(2) NOT NULL,
    cod_progr character varying(5) NOT NULL,
    creditos integer,
    tipo character(1),
    codigo integer NOT NULL,
    resolucion character varying(3)
);


ALTER TABLE public.cu_categorias OWNER TO dintev;

--
-- Name: COLUMN cu_categorias.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_categorias.tipo IS 'Indica si es del Basica o Profesional';


--
-- Name: cu_categorias_cursos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_categorias_cursos (
    codigo character varying(14) NOT NULL,
    cod_curso character(6) NOT NULL,
    cod_categoria integer NOT NULL,
    cod_subcategoria character varying(3)
);


ALTER TABLE public.cu_categorias_cursos OWNER TO dintev;

--
-- Name: TABLE cu_categorias_cursos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_categorias_cursos IS 'clasificacion de los cursos';


--
-- Name: COLUMN cu_categorias_cursos.codigo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_categorias_cursos.codigo IS 'cod_curso+cod_categoria';


--
-- Name: cu_ciclos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_ciclos (
    codigo character varying(2) NOT NULL,
    nombre character varying(30) NOT NULL
);


ALTER TABLE public.cu_ciclos OWNER TO dintev;

--
-- Name: cu_clases; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_clases (
    codigo character varying(14) NOT NULL,
    cod_horario character varying(12),
    fecha date,
    observaciones text,
    updated_at timestamp without time zone DEFAULT now(),
    updated_by integer,
    anuncios character varying(50)
);


ALTER TABLE public.cu_clases OWNER TO dintev;

--
-- Name: TABLE cu_clases; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_clases IS 'Listado de Clases';


--
-- Name: COLUMN cu_clases.cod_horario; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.cod_horario IS 'codigo del horario';


--
-- Name: COLUMN cu_clases.fecha; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.fecha IS 'fecha en que se impartio la clase';


--
-- Name: COLUMN cu_clases.observaciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.observaciones IS 'Anotaciones sobre la clase con respecto a la  asistencia';


--
-- Name: COLUMN cu_clases.updated_at; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.updated_at IS 'hora en que se realizo la ultima actualizacion';


--
-- Name: COLUMN cu_clases.updated_by; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.updated_by IS 'cod_interno de quien realizo la ultima actualizacion';


--
-- Name: COLUMN cu_clases.anuncios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_clases.anuncios IS 'Anuncios u Observaciones sobre la clase';


--
-- Name: cu_componentes_cursos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_componentes_cursos (
    codigo character(14) NOT NULL,
    cod_docente integer,
    cod_componente character(6) NOT NULL,
    semestre integer NOT NULL,
    observaciones text,
    cod_curso integer NOT NULL,
    cod_horario character varying(12),
    fecha_inicio date,
    fecha_fin date
);


ALTER TABLE public.cu_componentes_cursos OWNER TO dintev;

--
-- Name: TABLE cu_componentes_cursos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_componentes_cursos IS 'Relaciona componentes con cursos';


--
-- Name: COLUMN cu_componentes_cursos.cod_docente; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.cod_docente IS 'C�digo del docente que ense�a el componente';


--
-- Name: COLUMN cu_componentes_cursos.cod_componente; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.cod_componente IS 'C�digo del componente (materia)';


--
-- Name: COLUMN cu_componentes_cursos.cod_curso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.cod_curso IS 'C�digo del curso';


--
-- Name: COLUMN cu_componentes_cursos.cod_horario; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.cod_horario IS 'C�digo del horario de un componente en un curso durante un semestre determinado: cod_curso+cod_componente+semestre';


--
-- Name: COLUMN cu_componentes_cursos.fecha_inicio; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.fecha_inicio IS 'Fecha de inicio del componente durante el semestre';


--
-- Name: COLUMN cu_componentes_cursos.fecha_fin; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_componentes_cursos.fecha_fin IS 'Fecha de finalizaci�n del componente durante el semestre';


--
-- Name: cu_horarios; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_horarios (
    codigo character varying(12) NOT NULL,
    dia smallint,
    hora_inicio time without time zone,
    hora_fin time without time zone,
    sede smallint,
    edificio character varying(30),
    salon character varying(30),
    CONSTRAINT cu_horarios_check_dia CHECK (((dia >= 0) AND (dia < 7))),
    CONSTRAINT cu_horarios_check_hora_fin CHECK ((hora_fin > hora_inicio))
);


ALTER TABLE public.cu_horarios OWNER TO dintev;

--
-- Name: TABLE cu_horarios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_horarios IS 'Horarios de los Cursos';


--
-- Name: cu_porcentajes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_porcentajes (
    consecutivo integer NOT NULL,
    cod_curso character(6) NOT NULL,
    fecha1 date,
    fecha2 date,
    total_notas numeric(2,0),
    vigente character varying(2)
);


ALTER TABLE public.cu_porcentajes OWNER TO dintev;

--
-- Name: cu_porcentajes_notas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_porcentajes_notas (
    consecutivo integer NOT NULL,
    conse_porcentaje integer NOT NULL,
    cod_tipo_evalu integer NOT NULL,
    porcentaje numeric(4,3)
);


ALTER TABLE public.cu_porcentajes_notas OWNER TO dintev;

--
-- Name: cu_subcategorias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_subcategorias (
    codigo character varying(3) NOT NULL,
    cod_area character varying(3),
    nombre character varying(100) NOT NULL
);


ALTER TABLE public.cu_subcategorias OWNER TO dintev;

--
-- Name: cu_tipos_evaluaciones; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_tipos_evaluaciones (
    codigo integer NOT NULL,
    nombre character varying(20) NOT NULL,
    sigla character varying(2) NOT NULL
);


ALTER TABLE public.cu_tipos_evaluaciones OWNER TO dintev;

--
-- Name: TABLE cu_tipos_evaluaciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE cu_tipos_evaluaciones IS 'Diferentes tipos de evaluaciones';


--
-- Name: COLUMN cu_tipos_evaluaciones.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_tipos_evaluaciones.nombre IS 'Nombre del tipo de evaluaci�n';


--
-- Name: COLUMN cu_tipos_evaluaciones.sigla; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN cu_tipos_evaluaciones.sigla IS 'Sigla del tipo de evaluaci�n';


--
-- Name: cu_unidades_academicas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE cu_unidades_academicas (
    codigo bigint NOT NULL,
    nombre character varying(60),
    cod_jefe bigint,
    cargo_jefe character varying(200)
);


ALTER TABLE public.cu_unidades_academicas OWNER TO dintev;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO dintev;

--
-- Name: i_competencias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_competencias (
    codigo serial NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE public.i_competencias OWNER TO dintev;

--
-- Name: TABLE i_competencias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_competencias IS 'Competencias de ICFES';


--
-- Name: COLUMN i_competencias.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_competencias.nombre IS 'Nombre de la competencia';


--
-- Name: i_componentes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_componentes (
    codigo serial NOT NULL,
    nombre character varying(20) NOT NULL
);


ALTER TABLE public.i_componentes OWNER TO dintev;

--
-- Name: TABLE i_componentes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_componentes IS 'Componentes de ICFES';


--
-- Name: COLUMN i_componentes.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_componentes.nombre IS 'Nombre del componente';


--
-- Name: i_idiomas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_idiomas (
    codigo integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.i_idiomas OWNER TO dintev;

--
-- Name: TABLE i_idiomas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_idiomas IS 'Distintos idiomas de la prueba del ICFES';


--
-- Name: i_interdisciplinarias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_interdisciplinarias (
    codigo integer NOT NULL,
    nombre character varying NOT NULL
);


ALTER TABLE public.i_interdisciplinarias OWNER TO dintev;

--
-- Name: TABLE i_interdisciplinarias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_interdisciplinarias IS 'Distintas interdisciplinarias de la prueba del ICFES';


--
-- Name: COLUMN i_interdisciplinarias.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_interdisciplinarias.nombre IS 'Nombre la interdisciplinaria';


--
-- Name: i_preguntas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_preguntas (
    codigo serial NOT NULL,
    cod_componente integer NOT NULL,
    cod_competencia integer,
    numeral integer NOT NULL,
    respuesta character varying(4),
    valida boolean DEFAULT true,
    cod_prueba integer NOT NULL
);


ALTER TABLE public.i_preguntas OWNER TO dintev;

--
-- Name: TABLE i_preguntas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_preguntas IS 'Indica la respuesta correcta para una prueba dada';


--
-- Name: COLUMN i_preguntas.cod_componente; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_preguntas.cod_componente IS 'Componente al que pertenece la respuesta';


--
-- Name: COLUMN i_preguntas.cod_competencia; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_preguntas.cod_competencia IS 'Competencia del componente';


--
-- Name: COLUMN i_preguntas.numeral; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_preguntas.numeral IS 'Numeral de la pregunta';


--
-- Name: COLUMN i_preguntas.respuesta; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_preguntas.respuesta IS 'Indica la respuesta correcta';


--
-- Name: COLUMN i_preguntas.cod_prueba; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_preguntas.cod_prueba IS 'C�digo de la prueba espec�fica a la que corresponde esta respuesta';


--
-- Name: i_puntajes_competencias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_puntajes_competencias (
    codigo serial NOT NULL,
    cod_prueba integer NOT NULL,
    cod_interno integer NOT NULL,
    cod_componente integer NOT NULL,
    cod_competencia integer NOT NULL,
    puntaje numeric(4,2) NOT NULL
);


ALTER TABLE public.i_puntajes_competencias OWNER TO dintev;

--
-- Name: TABLE i_puntajes_competencias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_puntajes_competencias IS 'ALMACENA LOS PUNTAJES POR COMPETENCIA DE CADA COMPONENTE';


--
-- Name: COLUMN i_puntajes_competencias.cod_prueba; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_puntajes_competencias.cod_prueba IS 'equivale a TIPO PRUEBA en a_tipo_icfes';


--
-- Name: i_respuestas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_respuestas (
    codigo serial NOT NULL,
    cod_interno integer,
    cod_pregunta integer,
    a boolean,
    b boolean,
    c boolean,
    d boolean,
    e boolean
);


ALTER TABLE public.i_respuestas OWNER TO dintev;

SET default_with_oids = false;

--
-- Name: i_tipos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE i_tipos (
    codigo integer DEFAULT nextval('public.a_tipo_icfes_codigo_seq'::text) NOT NULL,
    nombre character varying(20) NOT NULL,
    tipo character varying(20) NOT NULL,
    fecha date NOT NULL,
    cod_programa character varying(5) NOT NULL
);


ALTER TABLE public.i_tipos OWNER TO dintev;

--
-- Name: TABLE i_tipos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE i_tipos IS 'Informaci�n sobre una prueba espec�fica';


--
-- Name: COLUMN i_tipos.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_tipos.nombre IS 'Nombre dado a la prueba';


--
-- Name: COLUMN i_tipos.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_tipos.tipo IS 'VALUES: SIMULACRO o PRUEBA OFICIAL';


--
-- Name: COLUMN i_tipos.fecha; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_tipos.fecha IS 'Fecha de Presentaci�n';


--
-- Name: COLUMN i_tipos.cod_programa; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN i_tipos.cod_programa IS 'CODIGO DEL PERIODO TALENTOS EN QUE SE REALIZA';


SET default_with_oids = true;

--
-- Name: p_discapacidades; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_discapacidades (
    codigo smallint NOT NULL,
    nombre character varying(20)
);


ALTER TABLE public.p_discapacidades OWNER TO dintev;

--
-- Name: TABLE p_discapacidades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_discapacidades IS 'Listado de Discapacidades';


--
-- Name: COLUMN p_discapacidades.codigo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_discapacidades.codigo IS 'codigo de la discapacidad';


--
-- Name: COLUMN p_discapacidades.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_discapacidades.nombre IS 'nombre de la discapacidad';


--
-- Name: p_estados_civiles; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_estados_civiles (
    codigo integer NOT NULL,
    nombre character varying(25) NOT NULL
);


ALTER TABLE public.p_estados_civiles OWNER TO dintev;

--
-- Name: TABLE p_estados_civiles; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_estados_civiles IS 'Diferentes tipos de estado civil';


--
-- Name: p_etnias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_etnias (
    codigo smallint NOT NULL,
    nombre character varying(17) NOT NULL
);


ALTER TABLE public.p_etnias OWNER TO dintev;

--
-- Name: TABLE p_etnias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_etnias IS 'Listado de Etnias';


--
-- Name: p_niveles; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_niveles (
    codigo integer NOT NULL,
    nombre character varying(15) NOT NULL
);


ALTER TABLE public.p_niveles OWNER TO dintev;

--
-- Name: p_oficios; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_oficios (
    codigo integer NOT NULL,
    nombre character varying(25) NOT NULL
);


ALTER TABLE public.p_oficios OWNER TO dintev;

--
-- Name: TABLE p_oficios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_oficios IS 'Diferentes tipos de oficios que una persona puede realizar';


--
-- Name: p_passwords; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_passwords (
    cod_interno integer NOT NULL,
    passwd character varying NOT NULL,
    primera_vez boolean DEFAULT true NOT NULL
);


ALTER TABLE public.p_passwords OWNER TO dintev;

--
-- Name: TABLE p_passwords; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_passwords IS 'Almacena las contrase�as de los usuarios';


--
-- Name: COLUMN p_passwords.primera_vez; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_passwords.primera_vez IS 'Indica si es la primera vez que se le asigna un password';


--
-- Name: p_tipos_cedulas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_tipos_cedulas (
    codigo integer NOT NULL,
    nombre character varying(30) NOT NULL,
    sigla character varying(8)
);


ALTER TABLE public.p_tipos_cedulas OWNER TO dintev;

--
-- Name: TABLE p_tipos_cedulas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_tipos_cedulas IS 'Diferentes tipos de documento de identidad';


--
-- Name: COLUMN p_tipos_cedulas.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_tipos_cedulas.nombre IS 'Nombre del tipo de documento de identidad';


--
-- Name: COLUMN p_tipos_cedulas.sigla; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_tipos_cedulas.sigla IS 'Sigla usada por el tipo de documento de identidad';


--
-- Name: p_tipos_personas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE p_tipos_personas (
    codigo integer NOT NULL,
    nombre character varying(20) NOT NULL
);


ALTER TABLE public.p_tipos_personas OWNER TO dintev;

--
-- Name: TABLE p_tipos_personas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE p_tipos_personas IS 'Tipos de persona, ejemplos: estudiante, docente, monitor, etc.';


--
-- Name: COLUMN p_tipos_personas.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN p_tipos_personas.nombre IS 'Nombre del tipo de persona';


SET default_with_oids = false;

--
-- Name: pe_causas_bloqueo; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_causas_bloqueo (
    codigo character varying(4) NOT NULL,
    nombre character varying(25)
);


ALTER TABLE public.pe_causas_bloqueo OWNER TO dintev;

--
-- Name: TABLE pe_causas_bloqueo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_causas_bloqueo IS 'Distintas causas para el bloqueo de una persona en el sistema';


--
-- Name: COLUMN pe_causas_bloqueo.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_causas_bloqueo.nombre IS 'Causa del bloqueo';


SET default_with_oids = true;

--
-- Name: pe_colegios_estudiantes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_colegios_estudiantes (
    cod_interno integer NOT NULL,
    cod_colegio character varying(12) NOT NULL,
    matematicas character(1),
    naturales character(1),
    sociales character(1),
    lenguaje character(1),
    fecha_bachiller integer NOT NULL
);


ALTER TABLE public.pe_colegios_estudiantes OWNER TO dintev;

--
-- Name: TABLE pe_colegios_estudiantes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_colegios_estudiantes IS 'Relaciona un estudiante con un colegio, muestra datos acad�micos del estudiante';


--
-- Name: COLUMN pe_colegios_estudiantes.cod_colegio; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.cod_colegio IS 'C�digo del colegio del que se gradu� el estudiante';


--
-- Name: COLUMN pe_colegios_estudiantes.matematicas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.matematicas IS 'Nota cualitativa en Matematicas';


--
-- Name: COLUMN pe_colegios_estudiantes.naturales; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.naturales IS 'Nota cualitativa en Naturales';


--
-- Name: COLUMN pe_colegios_estudiantes.sociales; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.sociales IS 'Nota cualitativa en Sociales';


--
-- Name: COLUMN pe_colegios_estudiantes.lenguaje; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.lenguaje IS 'Nota cualitativa en Lenguaje';


--
-- Name: COLUMN pe_colegios_estudiantes.fecha_bachiller; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_colegios_estudiantes.fecha_bachiller IS 'Fecha de grado del estudiante';


--
-- Name: pe_desplazados; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_desplazados (
    cod_interno integer NOT NULL,
    cod_ciudad character varying(10) NOT NULL
);


ALTER TABLE public.pe_desplazados OWNER TO dintev;

--
-- Name: TABLE pe_desplazados; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_desplazados IS 'Relacion de Estudiantes en Condicion de Desplazados';


--
-- Name: pe_egresados_trabajo; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_egresados_trabajo (
    cod_interno integer NOT NULL,
    ocupacion character varying(40)
);


ALTER TABLE public.pe_egresados_trabajo OWNER TO dintev;

--
-- Name: TABLE pe_egresados_trabajo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_egresados_trabajo IS 'Relaciona un egresado con su ocupaci�n actual';


--
-- Name: COLUMN pe_egresados_trabajo.ocupacion; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_egresados_trabajo.ocupacion IS 'Ocupaci�n desempe�ada';


--
-- Name: pe_embarazos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_embarazos (
    cod_interno integer NOT NULL,
    created_on date DEFAULT now(),
    updated_on date,
    CONSTRAINT pe_embarazos_check CHECK ((created_on < updated_on))
);


ALTER TABLE public.pe_embarazos OWNER TO dintev;

--
-- Name: TABLE pe_embarazos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_embarazos IS 'Listado de Estudiantes en estado de embarazo';


--
-- Name: COLUMN pe_embarazos.created_on; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_embarazos.created_on IS 'Fecha en que se registro';


--
-- Name: COLUMN pe_embarazos.updated_on; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_embarazos.updated_on IS 'Fecha en que se registra el fin del embarazo';


--
-- Name: pe_motivos_inasistencias; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_motivos_inasistencias (
    codigo smallint NOT NULL,
    nombre character varying(15) NOT NULL,
    valida boolean DEFAULT false
);


ALTER TABLE public.pe_motivos_inasistencias OWNER TO dintev;

--
-- Name: TABLE pe_motivos_inasistencias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_motivos_inasistencias IS 'Almacena los posibles motivos de Inasistencia';


SET default_with_oids = false;

--
-- Name: pe_observaciones; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pe_observaciones (
    codigo integer DEFAULT nextval('public.a_observaciones_estud_codigo_seq'::text) NOT NULL,
    cod_interno integer NOT NULL,
    tipo character varying NOT NULL,
    observacion text NOT NULL,
    fecha_registro date DEFAULT ('now'::text)::date,
    updated_by integer,
    autorizado_por character varying(30)
);


ALTER TABLE public.pe_observaciones OWNER TO dintev;

--
-- Name: TABLE pe_observaciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pe_observaciones IS 'Almacena las observaciones de los estudiantes';


--
-- Name: COLUMN pe_observaciones.observacion; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_observaciones.observacion IS 'Texto de la observaci�n';


--
-- Name: COLUMN pe_observaciones.fecha_registro; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_observaciones.fecha_registro IS 'Fecha en que se ingreso la observaci�n';


--
-- Name: COLUMN pe_observaciones.updated_by; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pe_observaciones.updated_by IS 'actualizado por';


SET default_with_oids = true;

--
-- Name: pr_cursos_programas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pr_cursos_programas (
    codigo character varying(15) NOT NULL,
    cod_programa character varying(5) NOT NULL,
    cod_curso character(6) NOT NULL,
    cod_categoria character(3),
    resolucion character varying(3) NOT NULL,
    semestre integer NOT NULL
);


ALTER TABLE public.pr_cursos_programas OWNER TO dintev;

--
-- Name: TABLE pr_cursos_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pr_cursos_programas IS 'Relaciona un componente con un programa en especial';


--
-- Name: COLUMN pr_cursos_programas.cod_curso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_cursos_programas.cod_curso IS 'C�digo del componente';


--
-- Name: COLUMN pr_cursos_programas.cod_categoria; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_cursos_programas.cod_categoria IS 'Categor�a del componente';


--
-- Name: COLUMN pr_cursos_programas.semestre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_cursos_programas.semestre IS 'Semestre en que se dicta el componente';


--
-- Name: pr_estudiantes_programas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pr_estudiantes_programas (
    codigo double precision NOT NULL,
    cod_interno integer NOT NULL,
    cod_programa character varying(5) NOT NULL,
    cod_progr_resol integer NOT NULL,
    cod_estud character(9),
    fecha_ingreso date,
    fecha_grado date,
    graduado character(2),
    cod_grupo integer NOT NULL
);


ALTER TABLE public.pr_estudiantes_programas OWNER TO dintev;

--
-- Name: TABLE pr_estudiantes_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pr_estudiantes_programas IS 'Relaciona un estudiante con un programa';


--
-- Name: COLUMN pr_estudiantes_programas.fecha_ingreso; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_estudiantes_programas.fecha_ingreso IS 'Fecha de ingreso al programa';


--
-- Name: COLUMN pr_estudiantes_programas.fecha_grado; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_estudiantes_programas.fecha_grado IS 'Fecha de grado del programa';


--
-- Name: COLUMN pr_estudiantes_programas.graduado; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_estudiantes_programas.graduado IS 'SI se gradu� o NO se gradu�';


--
-- Name: COLUMN pr_estudiantes_programas.cod_grupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_estudiantes_programas.cod_grupo IS 'C�digo del curso al que pertenece';


--
-- Name: pr_grupos_programas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pr_grupos_programas (
    codigo serial NOT NULL,
    cod_grupo integer,
    cod_programa character varying(5)
);


ALTER TABLE public.pr_grupos_programas OWNER TO dintev;

--
-- Name: TABLE pr_grupos_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pr_grupos_programas IS 'Relaciona un curso con un programa';


--
-- Name: COLUMN pr_grupos_programas.cod_grupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_grupos_programas.cod_grupo IS 'C�digo del curso';


--
-- Name: COLUMN pr_grupos_programas.cod_programa; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_grupos_programas.cod_programa IS 'C�digo del programa';


--
-- Name: pr_programas_resoluciones; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE pr_programas_resoluciones (
    consecutivo integer NOT NULL,
    cod_programa character varying(5) NOT NULL,
    num_rca character varying(3),
    num_rcs character varying(3),
    fecha_rca date,
    fecha_rcs date,
    vigente character varying(2)
);


ALTER TABLE public.pr_programas_resoluciones OWNER TO dintev;

--
-- Name: TABLE pr_programas_resoluciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE pr_programas_resoluciones IS 'Relaciona un programa con una resoluci�n';


--
-- Name: COLUMN pr_programas_resoluciones.num_rcs; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_programas_resoluciones.num_rcs IS 'N�mero de la resoluci�n';


--
-- Name: COLUMN pr_programas_resoluciones.fecha_rcs; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_programas_resoluciones.fecha_rcs IS 'Fecha de la resoluci�n';


--
-- Name: COLUMN pr_programas_resoluciones.vigente; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN pr_programas_resoluciones.vigente IS 'Indica si la resoluci�n SI est� vigente o NO est� vigente';


--
-- Name: r_pais_pai_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE r_pais_pai_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.r_pais_pai_codigo_seq OWNER TO dintev;

--
-- Name: r_region_reg_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE r_region_reg_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.r_region_reg_codigo_seq OWNER TO dintev;

--
-- Name: r_subdivisionpoliticamunicipal_spm_codigo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE r_subdivisionpoliticamunicipal_spm_codigo_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.r_subdivisionpoliticamunicipal_spm_codigo_seq OWNER TO dintev;

--
-- Name: re_carreras; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE re_carreras (
    codigo character varying(7) NOT NULL,
    nombre character varying(200) NOT NULL,
    cod_universidad character varying(10) NOT NULL,
    modalidad character varying(3) DEFAULT 'PR'::character varying NOT NULL,
    cod_ciudad character varying(10) NOT NULL
);


ALTER TABLE public.re_carreras OWNER TO dintev;

--
-- Name: TABLE re_carreras; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE re_carreras IS 'Carreras dadas en diferentes universidades';


--
-- Name: COLUMN re_carreras.codigo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_carreras.codigo IS 'Codigo SNIES';


--
-- Name: COLUMN re_carreras.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_carreras.nombre IS 'Nombre de la carrera';


--
-- Name: COLUMN re_carreras.cod_universidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_carreras.cod_universidad IS 'Universidad a la que pertenece la carrera';


--
-- Name: COLUMN re_carreras.modalidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_carreras.modalidad IS 'Modalidad de la carrera';


--
-- Name: COLUMN re_carreras.cod_ciudad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_carreras.cod_ciudad IS 'Ciudad en la que est� ubicada la universidad';


--
-- Name: re_colegios; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE re_colegios (
    codigo character varying(12) NOT NULL,
    nombre character varying(80) NOT NULL,
    cod_ciudad integer DEFAULT 760001 NOT NULL,
    direccion character varying(50),
    telefono character varying(15),
    telefono2 character varying(15),
    fax character varying(15),
    apartado_aereo character varying(10),
    es_bilingue boolean,
    nombre_rector character varying(60),
    observacion text,
    tipo character varying(12)
);


ALTER TABLE public.re_colegios OWNER TO dintev;

--
-- Name: TABLE re_colegios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE re_colegios IS 'Informaci�n sobre colegios de distintas ciudades';


--
-- Name: COLUMN re_colegios.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_colegios.nombre IS 'Nombre del colegio';


--
-- Name: COLUMN re_colegios.cod_ciudad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_colegios.cod_ciudad IS 'C�digo de la ciudad donde est� ubicado el colegio';


--
-- Name: COLUMN re_colegios.direccion; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_colegios.direccion IS 'Direcci�n del colegio';


--
-- Name: COLUMN re_colegios.observacion; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_colegios.observacion IS 'Observaciones sobre el colegio';


--
-- Name: COLUMN re_colegios.tipo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_colegios.tipo IS 'PRIVADO / OFICIAL';


--
-- Name: re_escuelas; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE re_escuelas (
    codigo bigint NOT NULL,
    nombre character varying(60) NOT NULL,
    cod_unidad bigint NOT NULL,
    nombre_corto character varying(15)
);


ALTER TABLE public.re_escuelas OWNER TO dintev;

--
-- Name: TABLE re_escuelas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE re_escuelas IS 'Escuela, Departamento o Instituto';


--
-- Name: re_sedes; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE re_sedes (
    codigo integer NOT NULL,
    nombre character varying(25) NOT NULL,
    direccion character varying(60),
    cod_corregi character varying(20),
    telefono character varying(15),
    tel_alterno character varying(15)
);


ALTER TABLE public.re_sedes OWNER TO dintev;

--
-- Name: TABLE re_sedes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE re_sedes IS 'Sedes donde se dictan las clases del Plan Talentos';


--
-- Name: COLUMN re_sedes.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_sedes.nombre IS 'Nombre de la sede';


SET default_with_oids = false;

--
-- Name: re_universidades; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE re_universidades (
    codigo integer DEFAULT nextval('public.a_universidades_codigo_seq'::text) NOT NULL,
    nombre character varying(100) NOT NULL,
    cod_ciudad character varying(30) NOT NULL,
    abreviatura character varying(15)
);


ALTER TABLE public.re_universidades OWNER TO dintev;

--
-- Name: TABLE re_universidades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE re_universidades IS 'Informaci�n universidades en distintas ciudades';


--
-- Name: COLUMN re_universidades.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_universidades.nombre IS 'Nombre de la universidad';


--
-- Name: COLUMN re_universidades.cod_ciudad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_universidades.cod_ciudad IS 'C�digo de la ciudad donde est� ubicada la universidad';


--
-- Name: COLUMN re_universidades.abreviatura; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN re_universidades.abreviatura IS 'Abreviatura del nombre de la universidad';


--
-- Name: reporte_periodo_consecutivo_seq; Type: SEQUENCE; Schema: public; Owner: dintev
--

CREATE SEQUENCE reporte_periodo_consecutivo_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.reporte_periodo_consecutivo_seq OWNER TO dintev;

SET default_with_oids = true;

--
-- Name: rg_barrios; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE rg_barrios (
    codigo integer NOT NULL,
    nombre character varying(80) NOT NULL
);


ALTER TABLE public.rg_barrios OWNER TO dintev;

--
-- Name: TABLE rg_barrios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE rg_barrios IS 'Barrios';


--
-- Name: COLUMN rg_barrios.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_barrios.nombre IS 'Nombre del barrio';


--
-- Name: rg_ciudades; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE rg_ciudades (
    codigo character varying(10) NOT NULL,
    nombre character varying(30) NOT NULL,
    cod_departamento integer DEFAULT 0
);


ALTER TABLE public.rg_ciudades OWNER TO dintev;

--
-- Name: TABLE rg_ciudades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE rg_ciudades IS 'Ciudades con su respectivo departamento';


--
-- Name: COLUMN rg_ciudades.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_ciudades.nombre IS 'Nombre del departamento';


--
-- Name: COLUMN rg_ciudades.cod_departamento; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_ciudades.cod_departamento IS 'C�digo del departamento al que pertenece la ciudad';


--
-- Name: rg_departamentos; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE rg_departamentos (
    codigo integer NOT NULL,
    nombre character varying(30) NOT NULL,
    cod_pais integer NOT NULL
);


ALTER TABLE public.rg_departamentos OWNER TO dintev;

--
-- Name: COLUMN rg_departamentos.cod_pais; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_departamentos.cod_pais IS 'c�digo del pa�s';


--
-- Name: rg_paises; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE rg_paises (
    codigo integer NOT NULL,
    nombre character varying(30) NOT NULL,
    nacionalidad character varying(30)
);


ALTER TABLE public.rg_paises OWNER TO dintev;

--
-- Name: TABLE rg_paises; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE rg_paises IS 'Paises con su nacionalidad';


--
-- Name: COLUMN rg_paises.nombre; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_paises.nombre IS 'Nombre del pa�s';


--
-- Name: COLUMN rg_paises.nacionalidad; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON COLUMN rg_paises.nacionalidad IS 'Nacionalidad para ese pa�s';


--
-- Name: rg_subdivisiones; Type: TABLE; Schema: public; Owner: dintev; Tablespace: 
--

CREATE TABLE rg_subdivisiones (
    spm_codigo integer NOT NULL,
    spm_nombre character varying(80) NOT NULL,
    spm_csp_codigo integer DEFAULT 0 NOT NULL,
    spm_ciu_codigo integer DEFAULT 0 NOT NULL,
    spm_usu_login character varying(32) DEFAULT 'none'::character varying NOT NULL,
    spm_fecha_modificacion timestamp without time zone DEFAULT ('now'::text)::timestamp(6) with time zone NOT NULL,
    spm_registro_vigente boolean DEFAULT true NOT NULL
);


ALTER TABLE public.rg_subdivisiones OWNER TO dintev;

--
-- Name: TABLE rg_subdivisiones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON TABLE rg_subdivisiones IS 'Subdivisiones Politicas Municipales';


--
-- Name: v_ciudades_colombianas; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_ciudades_colombianas AS
    SELECT rg_ciudades.codigo, rg_ciudades.nombre, rg_ciudades.cod_departamento, rg_departamentos.nombre AS nombre_departamento FROM (rg_ciudades JOIN rg_departamentos ON ((rg_ciudades.cod_departamento = rg_departamentos.codigo))) WHERE (rg_departamentos.cod_pais = 1);


ALTER TABLE public.v_ciudades_colombianas OWNER TO dintev;

--
-- Name: VIEW v_ciudades_colombianas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_ciudades_colombianas IS 'Listado de Ciudades Colombianas';


--
-- Name: v_componentes_programas; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_componentes_programas AS
    SELECT DISTINCT cu_componentes_cursos.cod_componente, a_componentes.nombre AS nombre_componente, a_grupos.cod_programa, cu_componentes_cursos.semestre FROM ((cu_componentes_cursos JOIN a_componentes ON ((a_componentes.codigo = cu_componentes_cursos.cod_componente))) JOIN a_grupos ON ((cu_componentes_cursos.cod_curso = a_grupos.codigo))) ORDER BY a_grupos.cod_programa, cu_componentes_cursos.semestre, cu_componentes_cursos.cod_componente, a_componentes.nombre;


ALTER TABLE public.v_componentes_programas OWNER TO dintev;

--
-- Name: VIEW v_componentes_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_componentes_programas IS 'Muestra los componentes relacionados a cada programa, por semestre';


--
-- Name: v_grupo; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_grupo AS
    SELECT a_grupo.codigo AS cod_grupo, (((a_grupo.grupo)::text || '-'::text) || lpad((a_grupo.subgrupo)::text, 2, '0'::text)) AS nombre_grupo, a_grupo.grupo, a_grupo.subgrupo, a_grupo.tipo, a_grupo.cod_programa FROM a_grupos a_grupo ORDER BY a_grupo.codigo;


ALTER TABLE public.v_grupo OWNER TO dintev;

--
-- Name: VIEW v_grupo; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_grupo IS 'Muestra los grupos del Plan Talentos y los relaciona con el programa al que pertenecen';


--
-- Name: v_cursos_docentes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_cursos_docentes AS
    SELECT a_persona.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.telefono, a_persona.tel_celular, cu_cursos_grupos.cod_componente AS cod_curso, a_cursos.nombre AS nombre_curso, cu_cursos_grupos.cod_curso AS cod_grupo, v_grupo.nombre_grupo, v_grupo.cod_programa FROM (((cu_componentes_cursos cu_cursos_grupos JOIN a_persona ON ((cu_cursos_grupos.cod_docente = a_persona.cod_interno))) JOIN a_componentes a_cursos ON ((cu_cursos_grupos.cod_componente = a_cursos.codigo))) JOIN v_grupo ON ((cu_cursos_grupos.cod_curso = v_grupo.cod_grupo)));


ALTER TABLE public.v_cursos_docentes OWNER TO dintev;

--
-- Name: VIEW v_cursos_docentes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_cursos_docentes IS 'Relaciona un profesor con un componente y un grupo dentro de un programa especifico del Plan Talentos';


--
-- Name: v_docentes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_docentes AS
    SELECT a_persona.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.genero, a_persona.telefono, a_persona.tel_celular, a_persona.direccion, a_persona.email, rg_ciudades.nombre AS ciudad, a_persona.fecha_ingreso FROM (a_persona JOIN rg_ciudades ON (((rg_ciudades.codigo)::text = (a_persona.cod_ciudad)::text))) WHERE (a_persona.cod_tipo_per = 2);


ALTER TABLE public.v_docentes OWNER TO dintev;

--
-- Name: VIEW v_docentes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_docentes IS 'Profesores con su informaci�n b�sica y fecha de ingreso';


--
-- Name: v_estudiantes_programas; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_programas AS
    SELECT a_estudiantes_grupos.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.cod_estado, t_grupos_programas.cod_programa FROM ((a_estudiantes_grupos JOIN (SELECT pr_grupos_programas.cod_grupo, pr_grupos_programas.cod_programa FROM pr_grupos_programas) t_grupos_programas USING (cod_grupo)) JOIN a_persona USING (cod_interno));


ALTER TABLE public.v_estudiantes_programas OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_programas; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_programas IS 'Relaciona un estudiante con el programa al que pertenece y el estado en que se encuentra';


--
-- Name: v_egresados; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_egresados AS
    SELECT v_estudiantes_programas.cod_interno, v_estudiantes_programas.fullname, v_estudiantes_programas.cod_programa, pe_estudiantes_universidades.cod_universidad FROM (pe_estudiantes_universidades FULL JOIN v_estudiantes_programas USING (cod_interno)) WHERE ((NOT (v_estudiantes_programas.cod_interno IN (SELECT a_bloqueados.cod_interno FROM a_bloqueados))) AND (v_estudiantes_programas.cod_programa IN (SELECT a_programas.codigo FROM a_programas WHERE (a_programas.fecha_cierre_1 < ('now'::text)::date))));


ALTER TABLE public.v_egresados OWNER TO dintev;

--
-- Name: VIEW v_egresados; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_egresados IS 'Relaciona los egresados del Plan Talentos y la universidad donde ingresaron, si es que han ingresado a alguna';


--
-- Name: v_egresados_universidades; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_egresados_universidades AS
    SELECT pe_estudiantes_universidades.cod_interno, v_estudiantes_programas.cedula, v_estudiantes_programas.fullname, v_estudiantes_programas.cod_programa, pe_estudiantes_universidades.cod_universidad, pe_estudiantes_universidades.cod_carrera, re_universidades.nombre AS nombre_universidad, re_carreras.nombre AS nombre_carrera, rg_ciudades.nombre AS nombre_ciudad FROM ((((pe_estudiantes_universidades JOIN v_estudiantes_programas USING (cod_interno)) LEFT JOIN re_universidades ON ((pe_estudiantes_universidades.cod_universidad = re_universidades.codigo))) LEFT JOIN re_carreras ON (((pe_estudiantes_universidades.cod_carrera)::text = (re_carreras.codigo)::text))) LEFT JOIN rg_ciudades ON (((re_universidades.cod_ciudad)::text = (rg_ciudades.codigo)::text)));


ALTER TABLE public.v_egresados_universidades OWNER TO dintev;

--
-- Name: VIEW v_egresados_universidades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_egresados_universidades IS 'Relaciona los egresados del Plan Talentos con la universidad y la carrera donde ingresaron, as� como con la ciudad sede de la universidad';


--
-- Name: v_estudiantes_activos; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_activos AS
    SELECT a_persona.cod_interno, a_persona.cedula, a_persona.nombres, a_persona.apellidos, (((a_persona.apellidos)::text || ', '::text) || (a_persona.nombres)::text) AS fullname, a_persona.genero, a_persona.email, a_persona.telefono, a_persona.telefono_alt, a_persona.tel_celular, a_persona.direccion FROM a_persona WHERE (((a_persona.cod_tipo_per = 1) AND (NOT (a_persona.cod_interno IN (SELECT a_bloqueados.cod_interno FROM a_bloqueados)))) AND (NOT (a_persona.cod_interno IN (SELECT v_egresados.cod_interno FROM v_egresados))));


ALTER TABLE public.v_estudiantes_activos OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_activos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_activos IS 'Muestra �nicamente los estudiantes activos del Plan Talentos';


--
-- Name: v_estudiantes_grupos; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_grupos AS
    SELECT a_estudiantes_grupos.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.cod_estado, a_estudiantes_grupos.cod_grupo, t_grupos.grupo, t_grupos.subgrupo, t_grupos.tipo AS tipo_grupo, t_grupos.nombre_grupo, t_grupos_programas.cod_programa FROM (((a_estudiantes_grupos JOIN (SELECT a_grupos.codigo AS cod_grupo, a_grupos.grupo, a_grupos.subgrupo, a_grupos.tipo, (((a_grupos.grupo)::text || '-'::text) || lpad((a_grupos.subgrupo)::text, 2, (0)::text)) AS nombre_grupo FROM a_grupos ORDER BY (((a_grupos.grupo)::text || '-'::text) || lpad((a_grupos.subgrupo)::text, 2, (0)::text))) t_grupos USING (cod_grupo)) JOIN (SELECT pr_grupos_programas.cod_grupo, pr_grupos_programas.cod_programa FROM pr_grupos_programas) t_grupos_programas USING (cod_grupo)) JOIN a_persona USING (cod_interno));


ALTER TABLE public.v_estudiantes_grupos OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_grupos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_grupos IS 'Relaciona un estudiante con el grupo y el programa al que pertenece dentro del Plan Talentos';


--
-- Name: v_estudiantes_colegios; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_colegios AS
    SELECT v_estudiantes_grupos.cod_interno, v_estudiantes_grupos.cedula, v_estudiantes_grupos.fullname, pe_colegios_estudiantes.cod_colegio, re_colegios.nombre AS nombre_colegio, re_colegios.tipo AS tipo_colegio, v_estudiantes_grupos.cod_grupo, v_estudiantes_grupos.nombre_grupo, v_estudiantes_grupos.cod_programa FROM ((v_estudiantes_grupos LEFT JOIN pe_colegios_estudiantes USING (cod_interno)) JOIN re_colegios ON (((pe_colegios_estudiantes.cod_colegio)::text = (re_colegios.codigo)::text)));


ALTER TABLE public.v_estudiantes_colegios OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_colegios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_colegios IS 'Relaciona los estudiantes con sus respectivos colegios';


--
-- Name: v_estudiantes_icfes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_icfes AS
    SELECT v_estudiantes_activos.cod_interno, v_estudiantes_activos.cedula, v_estudiantes_activos.fullname AS nombrecompleto, a_icfes.num_registro_icfes, a_icfes.lenguaje, a_icfes.matematica, COALESCE(a_icfes.sociales, ((a_icfes.historia + a_icfes.geografia) / (2)::numeric)) AS sociales, a_icfes.filosofia, a_icfes.biologia, a_icfes.quimica, a_icfes.fisica, tnombreidioma.nombre_idioma, a_icfes.idioma, tnombreinterdisciplinar.nombre_interdisciplinar, a_icfes.interdisciplinar, a_icfes.tipo, ttipoprueba.nombre_tipo_prueba FROM ((((v_estudiantes_activos NATURAL JOIN a_estudiantes_icfes a_icfes) LEFT JOIN (SELECT a_tipo_icfes.codigo, a_tipo_icfes.nombre AS nombre_tipo_prueba FROM i_tipos a_tipo_icfes) ttipoprueba ON ((ttipoprueba.codigo = a_icfes.tipo))) LEFT JOIN (SELECT i_idioma.codigo, i_idioma.nombre AS nombre_idioma FROM i_idiomas i_idioma) tnombreidioma ON ((tnombreidioma.codigo = a_icfes.cod_idioma))) LEFT JOIN (SELECT i_interdisciplinar.codigo, i_interdisciplinar.nombre AS nombre_interdisciplinar FROM i_interdisciplinarias i_interdisciplinar) tnombreinterdisciplinar ON ((tnombreinterdisciplinar.codigo = a_icfes.cod_interdisciplinar)));


ALTER TABLE public.v_estudiantes_icfes OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_icfes; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_icfes IS 'Muestra los estudiantes activos del Plan Talentos, con sus respectivos puntajes del ICFES';


--
-- Name: v_estudiantes_inactivos; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_inactivos AS
    SELECT a_bloqueados.cod_interno, v_estudiantes_grupos.cedula, v_estudiantes_grupos.fullname, a_bloqueados.motivo AS cod_motivo, pe_causas_bloqueo.nombre AS nombre_motivo, a_bloqueados.fecha, a_bloqueados.updated_by, a_bloqueados.authorized_by, v_estudiantes_grupos.cod_grupo, v_estudiantes_grupos.nombre_grupo, v_estudiantes_grupos.cod_programa FROM ((a_bloqueados JOIN v_estudiantes_grupos USING (cod_interno)) JOIN pe_causas_bloqueo ON (((a_bloqueados.motivo)::text = (pe_causas_bloqueo.codigo)::text)));


ALTER TABLE public.v_estudiantes_inactivos OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_inactivos; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_inactivos IS 'Listado detallado de estudiantes inactivos';


--
-- Name: v_estudiantes_observaciones; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_estudiantes_observaciones AS
    SELECT v_estudiantes_grupos.cod_interno, v_estudiantes_grupos.cedula, v_estudiantes_grupos.fullname, v_estudiantes_grupos.cod_estado, v_estudiantes_grupos.cod_grupo, v_estudiantes_grupos.grupo, v_estudiantes_grupos.subgrupo, v_estudiantes_grupos.tipo_grupo, v_estudiantes_grupos.nombre_grupo, v_estudiantes_grupos.cod_programa, pe_observaciones.codigo, pe_observaciones.tipo, pe_observaciones.observacion, pe_observaciones.fecha_registro FROM (v_estudiantes_grupos JOIN pe_observaciones USING (cod_interno));


ALTER TABLE public.v_estudiantes_observaciones OWNER TO dintev;

--
-- Name: VIEW v_estudiantes_observaciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_estudiantes_observaciones IS 'Relacion detallada de los participantes con las observaciones';


--
-- Name: v_horarios; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_horarios AS
    SELECT cu_componentes_cursos.codigo, cu_componentes_cursos.cod_curso, cu_componentes_cursos.cod_componente, cu_componentes_cursos.cod_horario, cu_horarios.dia, cu_horarios.hora_inicio, cu_horarios.hora_fin, cu_horarios.sede, cu_horarios.edificio, cu_horarios.salon, cu_componentes_cursos.fecha_inicio, cu_componentes_cursos.fecha_fin, cu_componentes_cursos.observaciones, cu_componentes_cursos.semestre, a_componentes.nombre AS nombre_componente, cu_componentes_cursos.cod_docente, v_docentes.cedula AS cedula_docente, v_docentes.fullname AS nombre_docente FROM (((cu_componentes_cursos LEFT JOIN cu_horarios ON (((cu_componentes_cursos.cod_horario)::text = (cu_horarios.codigo)::text))) LEFT JOIN a_componentes ON ((cu_componentes_cursos.cod_componente = a_componentes.codigo))) LEFT JOIN v_docentes ON ((cu_componentes_cursos.cod_docente = v_docentes.cod_interno)));


ALTER TABLE public.v_horarios OWNER TO dintev;

--
-- Name: VIEW v_horarios; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_horarios IS 'Relaciona un componente con el profesor del componente, horario, sede, sal�n y edificio en que se dicta; y fechas de inicio y de fin dentro del semestre';


--
-- Name: v_inasistencias; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_inasistencias AS
    SELECT cu_asistencias.codigo AS cod_asistencia, cu_asistencias.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.telefono, a_persona.tel_celular, cu_clases.fecha, cu_clases.cod_horario, cu_asistencias.cod_clase, cu_asistencias.cod_motivo, cu_componentes_cursos.cod_componente, a_componentes.nombre AS nombre_componente, cu_componentes_cursos.cod_curso, v_grupo.nombre_grupo AS nombre_curso, v_grupo.cod_programa FROM (((((cu_asistencias NATURAL JOIN a_persona) JOIN cu_clases ON (((cu_asistencias.cod_clase)::text = (cu_clases.codigo)::text))) JOIN cu_componentes_cursos USING (cod_horario)) JOIN a_componentes ON ((cu_componentes_cursos.cod_componente = a_componentes.codigo))) JOIN v_grupo ON ((cu_componentes_cursos.cod_curso = v_grupo.cod_grupo))) WHERE ((a_persona.cod_estado = 11) AND (cu_asistencias.asiste IS FALSE));


ALTER TABLE public.v_inasistencias OWNER TO dintev;

--
-- Name: VIEW v_inasistencias; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_inasistencias IS 'Listado de Inasistencias';


--
-- Name: v_universidades; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW v_universidades AS
    SELECT re_universidades.codigo, re_universidades.nombre, re_universidades.cod_ciudad, rg_ciudades.nombre AS nombre_ciudad FROM (re_universidades JOIN rg_ciudades ON (((re_universidades.cod_ciudad)::text = (rg_ciudades.codigo)::text))) ORDER BY re_universidades.nombre;


ALTER TABLE public.v_universidades OWNER TO dintev;

--
-- Name: VIEW v_universidades; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW v_universidades IS 'Lista las universidades del pa�s con la ciudad donde est�n ubicadas';


--
-- Name: vi_estudiantes_observaciones; Type: VIEW; Schema: public; Owner: dintev
--

CREATE VIEW vi_estudiantes_observaciones AS
    SELECT cod_interno, v_estudiantes_grupos.cedula, v_estudiantes_grupos.fullname, v_estudiantes_grupos.cod_grupo, v_estudiantes_grupos.nombre_grupo, v_estudiantes_grupos.cod_programa, v_estudiantes_grupos.cod_estado, COALESCE(observaciones.total_observaciones, (0)::bigint) AS total_observaciones, COALESCE(memos.total_memos, (0)::bigint) AS total_memos FROM (((SELECT pe_observaciones.cod_interno, count(*) AS total_observaciones FROM pe_observaciones WHERE ((pe_observaciones.tipo)::text = 'OBSERVACION'::text) GROUP BY pe_observaciones.cod_interno) observaciones FULL JOIN (SELECT pe_observaciones.cod_interno, count(*) AS total_memos FROM pe_observaciones WHERE ((pe_observaciones.tipo)::text = 'MEMO'::text) GROUP BY pe_observaciones.cod_interno) memos USING (cod_interno)) JOIN v_estudiantes_grupos USING (cod_interno)) ORDER BY observaciones.total_observaciones, memos.total_memos;


ALTER TABLE public.vi_estudiantes_observaciones OWNER TO dintev;

--
-- Name: VIEW vi_estudiantes_observaciones; Type: COMMENT; Schema: public; Owner: dintev
--

COMMENT ON VIEW vi_estudiantes_observaciones IS 'Relaciona el conteo de observaciones por estudiante';


--
-- Name: a_area_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_areas
    ADD CONSTRAINT a_area_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_area_nombre_key OWNER TO dintev;

--
-- Name: a_area_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_areas
    ADD CONSTRAINT a_area_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_area_pkey OWNER TO dintev;

--
-- Name: a_asistencia_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_asistencia
    ADD CONSTRAINT a_asistencia_codigo_key UNIQUE (codigo);


ALTER INDEX public.a_asistencia_codigo_key OWNER TO dintev;

--
-- Name: a_asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_asistencia
    ADD CONSTRAINT a_asistencia_pkey PRIMARY KEY (cod_curso, cod_grupo, cod_periodo, fecha_clase);


ALTER INDEX public.a_asistencia_pkey OWNER TO dintev;

--
-- Name: a_barrio_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_barrios
    ADD CONSTRAINT a_barrio_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_barrio_nombre_key OWNER TO dintev;

--
-- Name: a_barrio_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_barrios
    ADD CONSTRAINT a_barrio_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_barrio_pkey OWNER TO dintev;

--
-- Name: a_bloq_unike_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_bloqueados
    ADD CONSTRAINT a_bloq_unike_key UNIQUE (cod_interno);


ALTER INDEX public.a_bloq_unike_key OWNER TO dintev;

--
-- Name: a_categoria_cur_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_categorias
    ADD CONSTRAINT a_categoria_cur_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_categoria_cur_pkey OWNER TO dintev;

--
-- Name: a_ciclos_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_ciclos
    ADD CONSTRAINT a_ciclos_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_ciclos_nombre_key OWNER TO dintev;

--
-- Name: a_colegio_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY re_colegios
    ADD CONSTRAINT a_colegio_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_colegio_pkey OWNER TO dintev;

--
-- Name: a_curso_categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_categorias_cursos
    ADD CONSTRAINT a_curso_categoria_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_curso_categoria_pkey OWNER TO dintev;

--
-- Name: a_detalle_asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_detalle_asistencia
    ADD CONSTRAINT a_detalle_asistencia_pkey PRIMARY KEY (cod_interno, cod_asistencia);


ALTER INDEX public.a_detalle_asistencia_pkey OWNER TO dintev;

--
-- Name: a_escuelas_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY re_escuelas
    ADD CONSTRAINT a_escuelas_codigo_key UNIQUE (codigo);


ALTER INDEX public.a_escuelas_codigo_key OWNER TO dintev;

--
-- Name: a_estado_civil_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_estados_civiles
    ADD CONSTRAINT a_estado_civil_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_estado_civil_nombre_key OWNER TO dintev;

--
-- Name: a_estud_progr_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_estudiantes_programas
    ADD CONSTRAINT a_estud_progr_pkey PRIMARY KEY (cod_interno, cod_programa, cod_progr_resol);


ALTER INDEX public.a_estud_progr_pkey OWNER TO dintev;

--
-- Name: a_estud_universidades_cod_interno_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_estudiantes_universidades
    ADD CONSTRAINT a_estud_universidades_cod_interno_key UNIQUE (cod_interno);


ALTER INDEX public.a_estud_universidades_cod_interno_key OWNER TO dintev;

--
-- Name: a_estud_universidades_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_estudiantes_universidades
    ADD CONSTRAINT a_estud_universidades_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_estud_universidades_pkey OWNER TO dintev;

--
-- Name: a_estudiantes_grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_estudiantes_grupos
    ADD CONSTRAINT a_estudiantes_grupos_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_estudiantes_grupos_pkey OWNER TO dintev;

--
-- Name: a_grupo_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_grupos
    ADD CONSTRAINT a_grupo_codigo_key UNIQUE (codigo);


ALTER INDEX public.a_grupo_codigo_key OWNER TO dintev;

--
-- Name: a_grupo_grupoMayor_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_grupos
    ADD CONSTRAINT "a_grupo_grupoMayor_key" UNIQUE (grupo, subgrupo, cod_programa, tipo);


ALTER INDEX public."a_grupo_grupoMayor_key" OWNER TO dintev;

--
-- Name: a_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_grupos
    ADD CONSTRAINT a_grupo_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_grupo_pkey OWNER TO dintev;

--
-- Name: a_horario_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_horario
    ADD CONSTRAINT a_horario_codigo_key UNIQUE (codigo);


ALTER INDEX public.a_horario_codigo_key OWNER TO dintev;

--
-- Name: a_icfes_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_estudiantes_icfes
    ADD CONSTRAINT a_icfes_pkey PRIMARY KEY (cod_interno, tipo);


ALTER INDEX public.a_icfes_pkey OWNER TO dintev;

--
-- Name: a_ipAutorizados_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_passwords
    ADD CONSTRAINT "a_ipAutorizados_pkey" PRIMARY KEY (cod_interno);


ALTER INDEX public."a_ipAutorizados_pkey" OWNER TO dintev;

--
-- Name: a_notas_colegio_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_colegios_estudiantes
    ADD CONSTRAINT a_notas_colegio_pkey PRIMARY KEY (cod_interno, cod_colegio);


ALTER INDEX public.a_notas_colegio_pkey OWNER TO dintev;

--
-- Name: a_observaciones_estud_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_observaciones
    ADD CONSTRAINT a_observaciones_estud_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_observaciones_estud_pkey OWNER TO dintev;

--
-- Name: a_periodo_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_periodo
    ADD CONSTRAINT a_periodo_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_periodo_nombre_key OWNER TO dintev;

--
-- Name: a_periodos_programas_cod_programa_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_periodos_programas
    ADD CONSTRAINT a_periodos_programas_cod_programa_key UNIQUE (cod_programa, cod_periodo);


ALTER INDEX public.a_periodos_programas_cod_programa_key OWNER TO dintev;

--
-- Name: a_periodos_programas_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_periodos_programas
    ADD CONSTRAINT a_periodos_programas_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_periodos_programas_pkey OWNER TO dintev;

--
-- Name: a_persona_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_pkey PRIMARY KEY (cod_interno);


ALTER INDEX public.a_persona_pkey OWNER TO dintev;

--
-- Name: a_profe_cur_llave_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT a_profe_cur_llave_key UNIQUE (codigo);


ALTER INDEX public.a_profe_cur_llave_key OWNER TO dintev;

--
-- Name: a_profe_cur_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT a_profe_cur_pkey PRIMARY KEY (cod_componente, semestre, cod_curso);


ALTER INDEX public.a_profe_cur_pkey OWNER TO dintev;

--
-- Name: a_programa_curso_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_cursos_programas
    ADD CONSTRAINT a_programa_curso_pkey PRIMARY KEY (codigo, resolucion);


ALTER INDEX public.a_programa_curso_pkey OWNER TO dintev;

--
-- Name: a_programa_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_programas
    ADD CONSTRAINT a_programa_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_programa_nombre_key OWNER TO dintev;

--
-- Name: a_subcategoria_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_subcategorias
    ADD CONSTRAINT a_subcategoria_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_subcategoria_pkey OWNER TO dintev;

--
-- Name: a_tipo_icfes_cod_programa_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_tipos
    ADD CONSTRAINT a_tipo_icfes_cod_programa_key UNIQUE (cod_programa, nombre);


ALTER INDEX public.a_tipo_icfes_cod_programa_key OWNER TO dintev;

--
-- Name: a_tipo_icfes_cod_programa_key1; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_tipos
    ADD CONSTRAINT a_tipo_icfes_cod_programa_key1 UNIQUE (cod_programa, fecha);


ALTER INDEX public.a_tipo_icfes_cod_programa_key1 OWNER TO dintev;

--
-- Name: a_tipo_icfes_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_tipos
    ADD CONSTRAINT a_tipo_icfes_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_tipo_icfes_pkey OWNER TO dintev;

--
-- Name: a_tipo_persona_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_tipos_personas
    ADD CONSTRAINT a_tipo_persona_nombre_key UNIQUE (nombre);


ALTER INDEX public.a_tipo_persona_nombre_key OWNER TO dintev;

--
-- Name: a_unidad_academica_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_unidades_academicas
    ADD CONSTRAINT a_unidad_academica_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_unidad_academica_pkey OWNER TO dintev;

--
-- Name: a_universidades_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY re_universidades
    ADD CONSTRAINT a_universidades_pkey PRIMARY KEY (codigo);


ALTER INDEX public.a_universidades_pkey OWNER TO dintev;

--
-- Name: cu_asistencias_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_asistencias
    ADD CONSTRAINT cu_asistencias_pkey PRIMARY KEY (codigo);


ALTER INDEX public.cu_asistencias_pkey OWNER TO dintev;

--
-- Name: cu_categorias_cursos_cod_curso_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_categorias_cursos
    ADD CONSTRAINT cu_categorias_cursos_cod_curso_key UNIQUE (cod_curso, cod_categoria, cod_subcategoria);


ALTER INDEX public.cu_categorias_cursos_cod_curso_key OWNER TO dintev;

--
-- Name: cu_clases_cod_horario_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_clases
    ADD CONSTRAINT cu_clases_cod_horario_key UNIQUE (cod_horario, fecha);


ALTER INDEX public.cu_clases_cod_horario_key OWNER TO dintev;

--
-- Name: cu_clases_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_clases
    ADD CONSTRAINT cu_clases_pkey PRIMARY KEY (codigo);


ALTER INDEX public.cu_clases_pkey OWNER TO dintev;

--
-- Name: cu_horarios_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_horarios
    ADD CONSTRAINT cu_horarios_pkey PRIMARY KEY (codigo);


ALTER INDEX public.cu_horarios_pkey OWNER TO dintev;

--
-- Name: i_competencias_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_competencias
    ADD CONSTRAINT i_competencias_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_competencias_pkey OWNER TO dintev;

--
-- Name: i_componentes_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_componentes
    ADD CONSTRAINT i_componentes_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_componentes_pkey OWNER TO dintev;

--
-- Name: i_idioma_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_idiomas
    ADD CONSTRAINT i_idioma_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_idioma_pkey OWNER TO dintev;

--
-- Name: i_interdisciplinar_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_interdisciplinarias
    ADD CONSTRAINT i_interdisciplinar_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_interdisciplinar_pkey OWNER TO dintev;

--
-- Name: i_preguntas_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_preguntas
    ADD CONSTRAINT i_preguntas_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_preguntas_pkey OWNER TO dintev;

--
-- Name: i_puntajes_competencias_cod_prueba_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_cod_prueba_key UNIQUE (cod_prueba, cod_interno, cod_componente, cod_competencia);


ALTER INDEX public.i_puntajes_competencias_cod_prueba_key OWNER TO dintev;

--
-- Name: i_puntajes_competencias_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_puntajes_competencias_pkey OWNER TO dintev;

--
-- Name: i_respuesta_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_respuestas
    ADD CONSTRAINT i_respuesta_pkey PRIMARY KEY (codigo);


ALTER INDEX public.i_respuesta_pkey OWNER TO dintev;

--
-- Name: i_respuestas_cod_interno_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY i_respuestas
    ADD CONSTRAINT i_respuestas_cod_interno_key UNIQUE (cod_interno, cod_pregunta);


ALTER INDEX public.i_respuestas_cod_interno_key OWNER TO dintev;

--
-- Name: p_discapacidades_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_discapacidades
    ADD CONSTRAINT p_discapacidades_pkey PRIMARY KEY (codigo);


ALTER INDEX public.p_discapacidades_pkey OWNER TO dintev;

--
-- Name: p_etnias_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_etnias
    ADD CONSTRAINT p_etnias_nombre_key UNIQUE (nombre);


ALTER INDEX public.p_etnias_nombre_key OWNER TO dintev;

--
-- Name: p_etnias_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_etnias
    ADD CONSTRAINT p_etnias_pkey PRIMARY KEY (codigo);


ALTER INDEX public.p_etnias_pkey OWNER TO dintev;

--
-- Name: p_niveles_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_niveles
    ADD CONSTRAINT p_niveles_nombre_key UNIQUE (nombre);


ALTER INDEX public.p_niveles_nombre_key OWNER TO dintev;

--
-- Name: p_tipos_cedulas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_tipos_cedulas
    ADD CONSTRAINT p_tipos_cedulas_nombre_key UNIQUE (nombre);


ALTER INDEX public.p_tipos_cedulas_nombre_key OWNER TO dintev;

--
-- Name: p_tipos_cedulas_sigla_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_tipos_cedulas
    ADD CONSTRAINT p_tipos_cedulas_sigla_key UNIQUE (sigla);


ALTER INDEX public.p_tipos_cedulas_sigla_key OWNER TO dintev;

--
-- Name: pe_causas_bloqueo_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_causas_bloqueo
    ADD CONSTRAINT pe_causas_bloqueo_pkey PRIMARY KEY (codigo);


ALTER INDEX public.pe_causas_bloqueo_pkey OWNER TO dintev;

--
-- Name: pe_desplazados_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_desplazados
    ADD CONSTRAINT pe_desplazados_pkey PRIMARY KEY (cod_interno);


ALTER INDEX public.pe_desplazados_pkey OWNER TO dintev;

--
-- Name: pe_egresados_trabajo_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_egresados_trabajo
    ADD CONSTRAINT pe_egresados_trabajo_pkey PRIMARY KEY (cod_interno);


ALTER INDEX public.pe_egresados_trabajo_pkey OWNER TO dintev;

--
-- Name: pe_embarazos_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_embarazos
    ADD CONSTRAINT pe_embarazos_pkey PRIMARY KEY (cod_interno);


ALTER INDEX public.pe_embarazos_pkey OWNER TO dintev;

--
-- Name: pe_motivos_inasistencias_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pe_motivos_inasistencias
    ADD CONSTRAINT pe_motivos_inasistencias_pkey PRIMARY KEY (codigo);


ALTER INDEX public.pe_motivos_inasistencias_pkey OWNER TO dintev;

--
-- Name: pk_a_activi_cur_consecutivo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_activi_cur
    ADD CONSTRAINT pk_a_activi_cur_consecutivo PRIMARY KEY (consecutivo);


ALTER INDEX public.pk_a_activi_cur_consecutivo OWNER TO dintev;

--
-- Name: pk_a_ciclo_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_ciclos
    ADD CONSTRAINT pk_a_ciclo_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_ciclo_codigo OWNER TO dintev;

--
-- Name: pk_a_curso_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_componentes
    ADD CONSTRAINT pk_a_curso_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_curso_codigo OWNER TO dintev;

--
-- Name: pk_a_estado_civil_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_estados_civiles
    ADD CONSTRAINT pk_a_estado_civil_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_estado_civil_codigo OWNER TO dintev;

--
-- Name: pk_a_estado_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_estados
    ADD CONSTRAINT pk_a_estado_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_estado_codigo OWNER TO dintev;

--
-- Name: pk_a_estud_curso_consecutivo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT pk_a_estud_curso_consecutivo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_estud_curso_consecutivo OWNER TO dintev;

--
-- Name: pk_a_nivel_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_niveles
    ADD CONSTRAINT pk_a_nivel_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_nivel_codigo OWNER TO dintev;

--
-- Name: pk_a_nodo_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY re_sedes
    ADD CONSTRAINT pk_a_nodo_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_nodo_codigo OWNER TO dintev;

--
-- Name: pk_a_oficio_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_oficios
    ADD CONSTRAINT pk_a_oficio_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_oficio_codigo OWNER TO dintev;

--
-- Name: pk_a_perido_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_periodo
    ADD CONSTRAINT pk_a_perido_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_perido_codigo OWNER TO dintev;

--
-- Name: pk_a_porcentaje_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_porcentajes
    ADD CONSTRAINT pk_a_porcentaje_codigo PRIMARY KEY (consecutivo);


ALTER INDEX public.pk_a_porcentaje_codigo OWNER TO dintev;

--
-- Name: pk_a_porcentaje_nota_conse; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_porcentajes_notas
    ADD CONSTRAINT pk_a_porcentaje_nota_conse PRIMARY KEY (consecutivo);


ALTER INDEX public.pk_a_porcentaje_nota_conse OWNER TO dintev;

--
-- Name: pk_a_programa_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_programas
    ADD CONSTRAINT pk_a_programa_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_programa_codigo OWNER TO dintev;

--
-- Name: pk_a_programa_resol_consecu; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_programas_resoluciones
    ADD CONSTRAINT pk_a_programa_resol_consecu PRIMARY KEY (consecutivo);


ALTER INDEX public.pk_a_programa_resol_consecu OWNER TO dintev;

--
-- Name: pk_a_tipo_cedula_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_tipos_cedulas
    ADD CONSTRAINT pk_a_tipo_cedula_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_tipo_cedula_codigo OWNER TO dintev;

--
-- Name: pk_a_tipo_evalu_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY cu_tipos_evaluaciones
    ADD CONSTRAINT pk_a_tipo_evalu_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_tipo_evalu_codigo OWNER TO dintev;

--
-- Name: pk_a_tipo_persona_codigo; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY p_tipos_personas
    ADD CONSTRAINT pk_a_tipo_persona_codigo PRIMARY KEY (codigo);


ALTER INDEX public.pk_a_tipo_persona_codigo OWNER TO dintev;

--
-- Name: pr_cursos_programas_cod_programa_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_cursos_programas
    ADD CONSTRAINT pr_cursos_programas_cod_programa_key UNIQUE (cod_programa, cod_curso, semestre);


ALTER INDEX public.pr_cursos_programas_cod_programa_key OWNER TO dintev;

--
-- Name: pr_grupos_programas_cod_grupo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_grupos_programas
    ADD CONSTRAINT pr_grupos_programas_cod_grupo_key UNIQUE (cod_grupo, cod_programa);


ALTER INDEX public.pr_grupos_programas_cod_grupo_key OWNER TO dintev;

--
-- Name: pr_grupos_programas_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY pr_grupos_programas
    ADD CONSTRAINT pr_grupos_programas_pkey PRIMARY KEY (codigo);


ALTER INDEX public.pr_grupos_programas_pkey OWNER TO dintev;

--
-- Name: r_cuidad_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_ciudades
    ADD CONSTRAINT r_cuidad_pkey PRIMARY KEY (codigo);


ALTER INDEX public.r_cuidad_pkey OWNER TO dintev;

--
-- Name: r_pais_pai_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_paises
    ADD CONSTRAINT r_pais_pai_codigo_key UNIQUE (codigo);


ALTER INDEX public.r_pais_pai_codigo_key OWNER TO dintev;

--
-- Name: r_pais_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_paises
    ADD CONSTRAINT r_pais_pkey PRIMARY KEY (codigo);


ALTER INDEX public.r_pais_pkey OWNER TO dintev;

--
-- Name: r_region_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_departamentos
    ADD CONSTRAINT r_region_pkey PRIMARY KEY (codigo);


ALTER INDEX public.r_region_pkey OWNER TO dintev;

--
-- Name: r_subdivisionpoliticamunicipal_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_subdivisiones
    ADD CONSTRAINT r_subdivisionpoliticamunicipal_pkey PRIMARY KEY (spm_codigo);


ALTER INDEX public.r_subdivisionpoliticamunicipal_pkey OWNER TO dintev;

--
-- Name: r_subdivisionpoliticamunicipal_spm_codigo_key; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_subdivisiones
    ADD CONSTRAINT r_subdivisionpoliticamunicipal_spm_codigo_key UNIQUE (spm_codigo);


ALTER INDEX public.r_subdivisionpoliticamunicipal_spm_codigo_key OWNER TO dintev;

--
-- Name: re_carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY re_carreras
    ADD CONSTRAINT re_carreras_pkey PRIMARY KEY (codigo);


ALTER INDEX public.re_carreras_pkey OWNER TO dintev;

--
-- Name: rg_ciudades_nombre_uniq; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY rg_ciudades
    ADD CONSTRAINT rg_ciudades_nombre_uniq UNIQUE (nombre, cod_departamento);


ALTER INDEX public.rg_ciudades_nombre_uniq OWNER TO dintev;

--
-- Name: unq_a_persona_cedula; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT unq_a_persona_cedula UNIQUE (cedula);


ALTER INDEX public.unq_a_persona_cedula OWNER TO dintev;

--
-- Name: unq_a_persona_cod_estud; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT unq_a_persona_cod_estud UNIQUE (cod_estud);


ALTER INDEX public.unq_a_persona_cod_estud OWNER TO dintev;

--
-- Name: unq_estudiantes_grupos_codigos; Type: CONSTRAINT; Schema: public; Owner: dintev; Tablespace: 
--

ALTER TABLE ONLY a_estudiantes_grupos
    ADD CONSTRAINT unq_estudiantes_grupos_codigos UNIQUE (cod_interno, cod_grupo);


ALTER INDEX public.unq_estudiantes_grupos_codigos OWNER TO dintev;

--
-- Name: cod_curso; Type: INDEX; Schema: public; Owner: dintev; Tablespace: 
--

CREATE INDEX cod_curso ON a_estud_curso USING btree (cod_curso);


ALTER INDEX public.cod_curso OWNER TO dintev;

--
-- Name: cod_interno; Type: INDEX; Schema: public; Owner: dintev; Tablespace: 
--

CREATE INDEX cod_interno ON a_estud_curso USING btree (cod_interno);


ALTER INDEX public.cod_interno OWNER TO dintev;

--
-- Name: pai_nombre_idx; Type: INDEX; Schema: public; Owner: dintev; Tablespace: 
--

CREATE UNIQUE INDEX pai_nombre_idx ON rg_paises USING btree (nombre);


ALTER INDEX public.pai_nombre_idx OWNER TO dintev;

--
-- Name: r_cuidad_nombre_idx; Type: INDEX; Schema: public; Owner: dintev; Tablespace: 
--

CREATE UNIQUE INDEX r_cuidad_nombre_idx ON rg_ciudades USING btree (nombre, cod_departamento);


ALTER INDEX public.r_cuidad_nombre_idx OWNER TO dintev;

--
-- Name: reg_nombre_idx; Type: INDEX; Schema: public; Owner: dintev; Tablespace: 
--

CREATE UNIQUE INDEX reg_nombre_idx ON rg_departamentos USING btree (nombre, cod_pais);


ALTER INDEX public.reg_nombre_idx OWNER TO dintev;

--
-- Name: $1; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY rg_departamentos
    ADD CONSTRAINT "$1" FOREIGN KEY (cod_pais) REFERENCES rg_paises(codigo) ON UPDATE CASCADE;


--
-- Name: a_activi_cur_cod_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_activi_cur
    ADD CONSTRAINT a_activi_cur_cod_grupo_fkey FOREIGN KEY (cod_grupo) REFERENCES a_grupos(codigo);


--
-- Name: a_asistencia_cod_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_asistencia
    ADD CONSTRAINT a_asistencia_cod_curso_fkey FOREIGN KEY (cod_curso, cod_grupo, cod_periodo) REFERENCES cu_componentes_cursos(cod_componente, cod_curso, semestre);


--
-- Name: a_asistencia_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_asistencia
    ADD CONSTRAINT a_asistencia_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_bloqueados_motivo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_bloqueados
    ADD CONSTRAINT a_bloqueados_motivo_fkey FOREIGN KEY (motivo) REFERENCES pe_causas_bloqueo(codigo);


--
-- Name: a_bloqueados_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_bloqueados
    ADD CONSTRAINT a_bloqueados_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES a_persona(cod_interno);


--
-- Name: a_categoria_cur_area_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias
    ADD CONSTRAINT a_categoria_cur_area_fkey FOREIGN KEY (cod_area) REFERENCES cu_areas(codigo);


--
-- Name: a_categoria_cur_ciclo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias
    ADD CONSTRAINT a_categoria_cur_ciclo_fkey FOREIGN KEY (cod_ciclo) REFERENCES cu_ciclos(codigo);


--
-- Name: a_categoria_cur_cod_progr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias
    ADD CONSTRAINT a_categoria_cur_cod_progr_fkey FOREIGN KEY (cod_progr) REFERENCES a_programas(codigo);


--
-- Name: a_curso_categoria_cod_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias_cursos
    ADD CONSTRAINT a_curso_categoria_cod_categoria_fkey FOREIGN KEY (cod_categoria) REFERENCES cu_categorias(codigo);


--
-- Name: a_curso_categoria_cod_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias_cursos
    ADD CONSTRAINT a_curso_categoria_cod_curso_fkey FOREIGN KEY (cod_curso) REFERENCES a_componentes(codigo);


--
-- Name: a_curso_categoria_cod_subcategoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_categorias_cursos
    ADD CONSTRAINT a_curso_categoria_cod_subcategoria_fkey FOREIGN KEY (cod_subcategoria) REFERENCES cu_subcategorias(codigo);


--
-- Name: a_detalle_asistencia_cod_asistencia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_detalle_asistencia
    ADD CONSTRAINT a_detalle_asistencia_cod_asistencia_fkey FOREIGN KEY (cod_asistencia) REFERENCES a_asistencia(codigo);


--
-- Name: a_detalle_asistencia_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_detalle_asistencia
    ADD CONSTRAINT a_detalle_asistencia_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_escuelas_cod_unidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY re_escuelas
    ADD CONSTRAINT a_escuelas_cod_unidad_fkey FOREIGN KEY (cod_unidad) REFERENCES cu_unidades_academicas(codigo);


--
-- Name: a_estud_curso_cod_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT a_estud_curso_cod_grupo_fkey FOREIGN KEY (cod_grupo) REFERENCES a_grupos(codigo);


--
-- Name: a_estud_progr_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_estudiantes_programas
    ADD CONSTRAINT a_estud_progr_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_estud_progr_cod_programa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_estudiantes_programas
    ADD CONSTRAINT a_estud_progr_cod_programa_fkey FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: a_estud_universidades_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pe_estudiantes_universidades
    ADD CONSTRAINT a_estud_universidades_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_estudiantes_grupos_cod_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_grupos
    ADD CONSTRAINT a_estudiantes_grupos_cod_grupo_fkey FOREIGN KEY (cod_grupo) REFERENCES a_grupos(codigo);


--
-- Name: a_estudiantes_grupos_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_grupos
    ADD CONSTRAINT a_estudiantes_grupos_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_estudiantes_grupos_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_grupos
    ADD CONSTRAINT a_estudiantes_grupos_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES a_persona(cod_interno);


--
-- Name: a_grupo_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_grupos
    ADD CONSTRAINT a_grupo_cod_interno_fkey FOREIGN KEY (cod_director) REFERENCES a_persona(cod_interno);


--
-- Name: a_grupo_cod_programa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_grupos
    ADD CONSTRAINT a_grupo_cod_programa_fkey FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: a_horario_cod_nodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_horario
    ADD CONSTRAINT a_horario_cod_nodo_fkey FOREIGN KEY (cod_nodo) REFERENCES re_sedes(codigo);


--
-- Name: a_icfes_cod_idioma_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_icfes
    ADD CONSTRAINT a_icfes_cod_idioma_fkey FOREIGN KEY (cod_idioma) REFERENCES i_idiomas(codigo);


--
-- Name: a_icfes_cod_interdisciplinar_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_icfes
    ADD CONSTRAINT a_icfes_cod_interdisciplinar_fkey FOREIGN KEY (cod_interdisciplinar) REFERENCES i_interdisciplinarias(codigo);


--
-- Name: a_icfes_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_icfes
    ADD CONSTRAINT a_icfes_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_icfes_tipo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estudiantes_icfes
    ADD CONSTRAINT a_icfes_tipo_fkey FOREIGN KEY (tipo) REFERENCES i_tipos(codigo);


--
-- Name: a_ipautorizados_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY p_passwords
    ADD CONSTRAINT a_ipautorizados_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_notas_colegio_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pe_colegios_estudiantes
    ADD CONSTRAINT a_notas_colegio_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: a_periodos_programas_cod_periodo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_periodos_programas
    ADD CONSTRAINT a_periodos_programas_cod_periodo_fkey FOREIGN KEY (cod_periodo) REFERENCES a_periodo(codigo);


--
-- Name: a_periodos_programas_cod_programa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_periodos_programas
    ADD CONSTRAINT a_periodos_programas_cod_programa_fkey FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: a_persona_barrio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_barrio_fkey FOREIGN KEY (barrio) REFERENCES rg_barrios(codigo);


--
-- Name: a_persona_cod_corregi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_corregi_fkey FOREIGN KEY (cod_ciudad) REFERENCES rg_ciudades(codigo);


--
-- Name: a_persona_cod_discapacidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_discapacidad_fkey FOREIGN KEY (cod_discapacidad) REFERENCES p_discapacidades(codigo);


--
-- Name: a_persona_cod_est_civil_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_est_civil_fkey FOREIGN KEY (cod_estado_civil) REFERENCES p_estados_civiles(codigo);


--
-- Name: a_persona_cod_etnia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_etnia_fkey FOREIGN KEY (cod_etnia) REFERENCES p_etnias(codigo);


--
-- Name: a_persona_cod_expedida_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_expedida_fkey FOREIGN KEY (cod_expedida) REFERENCES rg_ciudades(codigo);


--
-- Name: a_persona_cod_lug_nacim_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT a_persona_cod_lug_nacim_fkey FOREIGN KEY (cod_lugar_nacimiento) REFERENCES rg_ciudades(codigo);


--
-- Name: a_profe_cur_cod_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT a_profe_cur_cod_grupo_fkey FOREIGN KEY (cod_curso) REFERENCES a_grupos(codigo);


--
-- Name: a_subcategoria_cod_area_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_subcategorias
    ADD CONSTRAINT a_subcategoria_cod_area_fkey FOREIGN KEY (cod_area) REFERENCES cu_areas(codigo);


--
-- Name: cu_asistencias_cod_clase_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_asistencias
    ADD CONSTRAINT cu_asistencias_cod_clase_fkey FOREIGN KEY (cod_clase) REFERENCES cu_clases(codigo);


--
-- Name: cu_asistencias_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_asistencias
    ADD CONSTRAINT cu_asistencias_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: cu_asistencias_cod_motivo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_asistencias
    ADD CONSTRAINT cu_asistencias_cod_motivo_fkey FOREIGN KEY (cod_motivo) REFERENCES pe_motivos_inasistencias(codigo);


--
-- Name: cu_clases_cod_horario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_clases
    ADD CONSTRAINT cu_clases_cod_horario_fkey FOREIGN KEY (cod_horario) REFERENCES cu_horarios(codigo);


--
-- Name: cu_componentes_cursos_cod_horario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT cu_componentes_cursos_cod_horario_fkey FOREIGN KEY (cod_horario) REFERENCES cu_horarios(codigo);


--
-- Name: fk_a_activi_cur_cod_activi; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_activi_cur
    ADD CONSTRAINT fk_a_activi_cur_cod_activi FOREIGN KEY (cod_actividad) REFERENCES cu_tipos_evaluaciones(codigo);


--
-- Name: fk_a_activi_cur_cod_curso; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_activi_cur
    ADD CONSTRAINT fk_a_activi_cur_cod_curso FOREIGN KEY (cod_curso) REFERENCES a_componentes(codigo);


--
-- Name: fk_a_activi_cur_cod_periodo; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_activi_cur
    ADD CONSTRAINT fk_a_activi_cur_cod_periodo FOREIGN KEY (cod_periodo) REFERENCES a_periodo(codigo);


--
-- Name: fk_a_estud_curso_cod_curso; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_curso FOREIGN KEY (cod_curso) REFERENCES a_componentes(codigo);


--
-- Name: fk_a_estud_curso_cod_estado; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_estado FOREIGN KEY (cod_estado) REFERENCES a_estados(codigo);


--
-- Name: fk_a_estud_curso_cod_interno; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_interno FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: fk_a_estud_curso_cod_nivel; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_nivel FOREIGN KEY (cod_nivel) REFERENCES p_niveles(codigo);


--
-- Name: fk_a_estud_curso_cod_nodo; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_nodo FOREIGN KEY (cod_nodo) REFERENCES re_sedes(codigo);


--
-- Name: fk_a_estud_curso_cod_periodo; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_periodo FOREIGN KEY (cod_periodo) REFERENCES a_periodo(codigo);


--
-- Name: fk_a_estud_curso_cod_profesor; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_cod_profesor FOREIGN KEY (cod_profesor) REFERENCES a_persona(cod_interno);


--
-- Name: fk_a_estud_curso_conse_porcentaje; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_estud_curso
    ADD CONSTRAINT fk_a_estud_curso_conse_porcentaje FOREIGN KEY (conse_porcentaje) REFERENCES cu_porcentajes(consecutivo);


--
-- Name: fk_a_persona_cod_estado; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT fk_a_persona_cod_estado FOREIGN KEY (cod_estado) REFERENCES a_estados(codigo);


--
-- Name: fk_a_persona_cod_oficio; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT fk_a_persona_cod_oficio FOREIGN KEY (cod_oficio) REFERENCES p_oficios(codigo);


--
-- Name: fk_a_persona_cod_tipo_ced; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT fk_a_persona_cod_tipo_ced FOREIGN KEY (cod_tipo_ced) REFERENCES p_tipos_cedulas(codigo);


--
-- Name: fk_a_persona_cod_tipo_per; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_persona
    ADD CONSTRAINT fk_a_persona_cod_tipo_per FOREIGN KEY (cod_tipo_per) REFERENCES p_tipos_personas(codigo);


--
-- Name: fk_a_porcen_nota_cod_tipo; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_porcentajes_notas
    ADD CONSTRAINT fk_a_porcen_nota_cod_tipo FOREIGN KEY (cod_tipo_evalu) REFERENCES cu_tipos_evaluaciones(codigo);


--
-- Name: fk_a_porcen_nota_conse_por; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_porcentajes_notas
    ADD CONSTRAINT fk_a_porcen_nota_conse_por FOREIGN KEY (conse_porcentaje) REFERENCES cu_porcentajes(consecutivo);


--
-- Name: fk_a_porcentaje_cod_curso; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_porcentajes
    ADD CONSTRAINT fk_a_porcentaje_cod_curso FOREIGN KEY (cod_curso) REFERENCES a_componentes(codigo);


--
-- Name: fk_a_profe_cur_cod_curso; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT fk_a_profe_cur_cod_curso FOREIGN KEY (cod_componente) REFERENCES a_componentes(codigo);


--
-- Name: fk_a_profe_cur_cod_periodo; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY cu_componentes_cursos
    ADD CONSTRAINT fk_a_profe_cur_cod_periodo FOREIGN KEY (semestre) REFERENCES a_periodo(codigo);


--
-- Name: fk_a_progr_curso_cod_curso; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_cursos_programas
    ADD CONSTRAINT fk_a_progr_curso_cod_curso FOREIGN KEY (cod_curso) REFERENCES a_componentes(codigo);


--
-- Name: fk_a_progr_curso_cod_programa; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_cursos_programas
    ADD CONSTRAINT fk_a_progr_curso_cod_programa FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: fk_a_programa_cod_director; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY a_programas
    ADD CONSTRAINT fk_a_programa_cod_director FOREIGN KEY (cod_director) REFERENCES a_persona(cod_interno);


--
-- Name: fk_a_programa_resol_cod_prog; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_programas_resoluciones
    ADD CONSTRAINT fk_a_programa_resol_cod_prog FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: i_preguntas_cod_competencia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_preguntas
    ADD CONSTRAINT i_preguntas_cod_competencia_fkey FOREIGN KEY (cod_competencia) REFERENCES i_competencias(codigo);


--
-- Name: i_preguntas_cod_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_preguntas
    ADD CONSTRAINT i_preguntas_cod_componente_fkey FOREIGN KEY (cod_componente) REFERENCES i_componentes(codigo);


--
-- Name: i_preguntas_cod_prueba_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_preguntas
    ADD CONSTRAINT i_preguntas_cod_prueba_fkey FOREIGN KEY (cod_prueba) REFERENCES i_tipos(codigo);


--
-- Name: i_puntajes_competencias_cod_competencia_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_cod_competencia_fkey FOREIGN KEY (cod_competencia) REFERENCES i_competencias(codigo);


--
-- Name: i_puntajes_competencias_cod_componente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_cod_componente_fkey FOREIGN KEY (cod_componente) REFERENCES i_componentes(codigo);


--
-- Name: i_puntajes_competencias_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: i_puntajes_competencias_cod_prueba_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_puntajes_competencias
    ADD CONSTRAINT i_puntajes_competencias_cod_prueba_fkey FOREIGN KEY (cod_prueba) REFERENCES i_tipos(codigo);


--
-- Name: i_respuestas_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_respuestas
    ADD CONSTRAINT i_respuestas_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno);


--
-- Name: i_respuestas_cod_pregunta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY i_respuestas
    ADD CONSTRAINT i_respuestas_cod_pregunta_fkey FOREIGN KEY (cod_pregunta) REFERENCES i_preguntas(codigo);


--
-- Name: pe_desplazados_cod_ciudad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pe_desplazados
    ADD CONSTRAINT pe_desplazados_cod_ciudad_fkey FOREIGN KEY (cod_ciudad) REFERENCES rg_ciudades(codigo);


--
-- Name: pe_embarazos_cod_interno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pe_embarazos
    ADD CONSTRAINT pe_embarazos_cod_interno_fkey FOREIGN KEY (cod_interno) REFERENCES a_persona(cod_interno) ON DELETE CASCADE;


--
-- Name: pr_grupos_programas_cod_grupo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_grupos_programas
    ADD CONSTRAINT pr_grupos_programas_cod_grupo_fkey FOREIGN KEY (cod_grupo) REFERENCES a_grupos(codigo);


--
-- Name: pr_grupos_programas_cod_programa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY pr_grupos_programas
    ADD CONSTRAINT pr_grupos_programas_cod_programa_fkey FOREIGN KEY (cod_programa) REFERENCES a_programas(codigo);


--
-- Name: re_carreras_cod_ciudad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY re_carreras
    ADD CONSTRAINT re_carreras_cod_ciudad_fkey FOREIGN KEY (cod_ciudad) REFERENCES rg_ciudades(codigo);


--
-- Name: re_carreras_cod_universidad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY re_carreras
    ADD CONSTRAINT re_carreras_cod_universidad_fkey FOREIGN KEY (cod_universidad) REFERENCES re_universidades(codigo);


--
-- Name: re_universidades_cod_ciudad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY re_universidades
    ADD CONSTRAINT re_universidades_cod_ciudad_fkey FOREIGN KEY (cod_ciudad) REFERENCES rg_ciudades(codigo);


--
-- Name: rg_ciudades_cod_departamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dintev
--

ALTER TABLE ONLY rg_ciudades
    ADD CONSTRAINT rg_ciudades_cod_departamento_fkey FOREIGN KEY (cod_departamento) REFERENCES rg_departamentos(codigo);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

