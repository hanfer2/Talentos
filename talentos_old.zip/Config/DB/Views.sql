CREATE OR REPLACE VIEW v_estudiantes AS
SELECT a_persona.cod_estado, a_persona.cod_interno, a_persona.tel_celular, a_persona.email, a_persona.cedula, a_persona.nombres, a_persona.apellidos
   FROM a_persona
  WHERE a_persona.cod_tipo_per = 1;

--
-- Name: v_grupo; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_grupo AS
    SELECT a_grupo.codigo AS cod_grupo, (((a_grupo.grupo)::text || '-'::text) || lpad((a_grupo.subgrupo)::text, 2, '0'::text)) AS nombre_grupo, a_grupo.grupo, a_grupo.subgrupo, a_grupo.tipo, a_grupo.cod_programa FROM a_grupos a_grupo ORDER BY a_grupo.codigo;

--
-- Name: v_cursos_docentes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_cursos_docentes AS
    SELECT a_persona.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.telefono, a_persona.tel_celular, cu_cursos_grupos.cod_curso, a_cursos.nombre AS nombre_curso, cu_cursos_grupos.cod_grupo, v_grupo.nombre_grupo, v_grupo.cod_programa FROM (((cu_cursos_grupos JOIN a_persona ON ((cu_cursos_grupos.cod_docente = a_persona.cod_interno))) JOIN a_cursos ON ((cu_cursos_grupos.cod_curso = a_cursos.codigo))) JOIN v_grupo USING (cod_grupo));


--
-- Name: v_docentes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_docentes AS
    SELECT a_persona.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.genero, a_persona.telefono, a_persona.tel_celular, a_persona.direccion, a_persona.email, rg_ciudades.nombre AS ciudad, a_persona.fecha_ingreso FROM (a_persona JOIN rg_ciudades ON (((rg_ciudades.codigo)::text = (a_persona.cod_ciudad)::text))) WHERE (a_persona.cod_tipo_per = 2);


--
-- Name: v_estudiantes_programas; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_estudiantes_programas AS
    SELECT a_estudiantes_grupos.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_persona.cod_estado, t_grupos_programas.cod_programa FROM (((a_estudiantes_grupos JOIN (SELECT pr_grupos_programas.cod_grupo, pr_grupos_programas.cod_programa FROM pr_grupos_programas) t_grupos_programas USING (cod_grupo)) JOIN a_persona USING (cod_interno)));


--
-- Name: v_egresados; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_egresados AS
    SELECT v_estudiantes_programas.cod_interno, v_estudiantes_programas.fullname, v_estudiantes_programas.cod_programa, pe_estudiantes_universidades.cod_universidad FROM (pe_estudiantes_universidades FULL JOIN v_estudiantes_programas USING (cod_interno)) WHERE ((NOT (v_estudiantes_programas.cod_interno IN (SELECT a_bloqueados.cod_interno FROM a_bloqueados))) AND (v_estudiantes_programas.cod_programa IN (SELECT a_programas.codigo FROM a_programas WHERE (a_programas.fecha_cierre_1 < ('now'::text)::date))));

--
-- Name: v_egresados_universidades; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_egresados_universidades AS
    SELECT pe_estudiantes_universidades.cod_interno, v_estudiantes_programas.cedula, v_estudiantes_programas.fullname, v_estudiantes_programas.cod_programa, pe_estudiantes_universidades.cod_universidad, pe_estudiantes_universidades.cod_carrera, re_universidades.nombre AS nombre_universidad, re_carreras.nombre AS nombre_carrera, rg_ciudades.nombre AS nombre_ciudad FROM ((((pe_estudiantes_universidades JOIN v_estudiantes_programas USING (cod_interno)) LEFT JOIN re_universidades ON ((pe_estudiantes_universidades.cod_universidad = re_universidades.codigo))) LEFT JOIN re_carreras ON (((pe_estudiantes_universidades.cod_carrera)::text = (re_carreras.codigo)::text))) LEFT JOIN rg_ciudades ON (((re_universidades.cod_ciudad)::text = (rg_ciudades.codigo)::text)));

--
-- Name: v_estudiantes_activos; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_estudiantes_activos AS
    SELECT a_persona.cod_interno, a_persona.cedula, a_persona.nombres, a_persona.apellidos, (((a_persona.apellidos)::text || ', '::text) || (a_persona.nombres)::text) AS fullname, a_persona.genero, a_persona.email, a_persona.telefono, a_persona.telefono_alt, a_persona.tel_celular, a_persona.direccion FROM a_persona WHERE (((a_persona.cod_tipo_per = 1) AND (NOT (a_persona.cod_interno IN (SELECT a_bloqueados.cod_interno FROM a_bloqueados)))) AND (NOT (a_persona.cod_interno IN (SELECT v_egresados.cod_interno FROM v_egresados))));


--
-- Name: v_estudiantes_grupos; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_estudiantes_grupos AS
    SELECT a_estudiantes_grupos.cod_interno, a_persona.cedula, fullname(a_persona.*) AS fullname, a_estudiantes_grupos.cod_grupo, t_grupos.grupo, t_grupos.subgrupo, t_grupos.tipo AS tipo_grupo, t_grupos.nombre_grupo, t_grupos_programas.cod_programa FROM (((a_estudiantes_grupos JOIN (SELECT a_grupos.codigo AS cod_grupo, a_grupos.grupo, a_grupos.subgrupo, a_grupos.tipo, (((a_grupos.grupo)::text || '-'::text) || lpad((a_grupos.subgrupo)::text, 2, (0)::text)) AS nombre_grupo FROM a_grupos ORDER BY (((a_grupos.grupo)::text || '-'::text) || lpad((a_grupos.subgrupo)::text, 2, (0)::text))) t_grupos USING (cod_grupo)) JOIN (SELECT pr_grupos_programas.cod_grupo, pr_grupos_programas.cod_programa FROM pr_grupos_programas) t_grupos_programas USING (cod_grupo)) JOIN a_persona USING (cod_interno));

--
-- Name: v_estudiantes_icfes; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_estudiantes_icfes AS
    SELECT v_estudiantes_activos.cod_interno, v_estudiantes_activos.cedula, v_estudiantes_activos.fullname AS nombrecompleto, a_icfes.num_registro_icfes, a_icfes.lenguaje, a_icfes.matematica, COALESCE(a_icfes.sociales, ((a_icfes.historia + a_icfes.geografia) / (2)::numeric)) AS sociales, a_icfes.filosofia, a_icfes.biologia, a_icfes.quimica, a_icfes.fisica, tnombreidioma.nombre_idioma, a_icfes.idioma, tnombreinterdisciplinar.nombre_interdisciplinar, a_icfes.interdisciplinar, a_icfes.tipo, ttipoprueba.nombre_tipo_prueba FROM ((((v_estudiantes_activos NATURAL JOIN a_estudiantes_icfes a_icfes) LEFT JOIN (SELECT a_tipo_icfes.codigo, a_tipo_icfes.nombre AS nombre_tipo_prueba FROM i_tipos a_tipo_icfes) ttipoprueba ON ((ttipoprueba.codigo = a_icfes.tipo))) LEFT JOIN (SELECT i_idioma.codigo, i_idioma.nombre AS nombre_idioma FROM i_idiomas i_idioma) tnombreidioma ON ((tnombreidioma.codigo = a_icfes.cod_idioma))) LEFT JOIN (SELECT i_interdisciplinar.codigo, i_interdisciplinar.nombre AS nombre_interdisciplinar FROM i_interdisciplinarias i_interdisciplinar) tnombreinterdisciplinar ON ((tnombreinterdisciplinar.codigo = a_icfes.cod_interdisciplinar)));

--
-- Name: v_universidades; Type: VIEW; Schema: public; Owner: dintev
--

CREATE OR REPLACE VIEW v_universidades AS
    SELECT re_universidades.codigo, re_universidades.nombre, re_universidades.cod_ciudad, rg_ciudades.nombre AS nombre_ciudad FROM (re_universidades JOIN rg_ciudades ON (((re_universidades.cod_ciudad)::text = (rg_ciudades.codigo)::text))) ORDER BY re_universidades.nombre;
