<?php
 require_once 'constants.php';
 require_once CARPETA_LIBS . "Config.php";
 
 $config = &Config::getInstance();
 
 /** DEFAULTS ATTRIBUTES***/
 $config->updateCurrentModel('default');
 $config->add('primary_key','codigo');
 $config->add('order','codigo');
 $config->add('Estado','a_estados');
 
 require_once 'database.php';


 /** **/
 $config->updateCurrentModel('App');
 $config->add('Encoding','UTF-8');
 
?>
