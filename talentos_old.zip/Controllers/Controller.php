<?php
  /**
   * Clase Vista derivada de Smarty
   */
   require_once(CARPETA_VISTAS.'Vista.php');
  /**
   * Librerias necesarias para Smarty
   */
  require_once(CARPETA_VISTAS.'Vista.php');
  AppLoader::load('vendor/Smarty/Smarty');

	if(class_exists('Controller'))
		return;

	/**
	 * Clase Controller
	 */
	class Controller {

	 /**
	 * @var Vista
	 */
	 var $vista = null; 
	 /**
	 *
	 * @var array arreglo de los parametros enviado por el REQUEST
	 */
	 var $params = array();


	 function Controller() {
		$args = func_get_args();
		call_user_func_array(array(&$this, '__construct'), $args);
	 }

     /**
      * Constructor de la Clase Controller
      */
	 function __construct() {
		$this->vista = new Vista();
		$this->params = $_REQUEST;
		$this->post = $_POST;
		$this->includeModel("TPrograma");
		$this->current_user = $_SESSION[SESSION_PARENT_VAR];
    
		$this->AppConfig = &AppConfig::instance();
		//$this->Config = &Config::getInstance();
    
	 }

     /**
	 * Incluye los modelos necesarios
	 */
	 function includeModel() {
		$models = func_get_args();
		if (!empty($models)) {
		 foreach ($models as $model)
      AppLoader::load_model($model);
		}
	 }

	 /**
	  * ???
	  */
	 function index() {}

	 /**
	  * Redirige una accion
	  */
	 function _redirect_to($action, $params=array()){
		$this->vista->current_action = $action;
		$this->$action(any(params(), $params));
	 }

	 /**
	 * Muestra el mensaje -under construction- para paginas no concluidas
	 */
	 function under_construction(){
	 	if(!is_root_login()){
	 		$this->vista->layout = 'clean';
	 		$this->vista->show('under_construction');
		 	exit();
		}else{
			$this->vista->notify("Under Construction");
		}
	 }
   
	}

?>
