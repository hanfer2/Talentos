<?php

  /**
   * Clase ProgramasController extendida de Controller
   */
  class ProgramasController extends Controller{

    /**
	 * Constructor de la Clase ProgramasController
	 */
    function __construct(){
      parent::__construct();
      $this->includeModel("TPrograma");
      $this->vista->setTitle('Programas');
      $this->TPrograma = new TPrograma();
    }

	/**
	 * Muestra los PNATs
	 */
    function index(){
			if(!(is_admin_login() || is_coordinator_login()))
				return $this->vista->acceso_restringido();
      $programas = TPrograma::all();
      $this->vista->addJS('jquery.dataTable','jquery.ui.datepicker');
      $this->vista->set('programas',$programas);
      $this->vista->display();
    }

	/**
	 * Registra un nuevo PNAT
	 */
    function add(){
			if(!is_super_admin_login())
				return $this->vista->acceso_restringido();
      if(!empty($this->params['programa'])){
        TPrograma::add($this->params['programa']);
      }
    }

	/**
	 * Muestra informacion sobre un PNAT
	 */
    function view($params){
			$cod_programa = $params['cod_programa'];
			
			$this->includeModel('TComponente');
	
      if(is_student_login()){
				$cedula = user_logged_info('cedula');
				$this->includeModel("TPersona");
				$cod_programa = TPersona::cod_programa($cedula);
				$this->vista->set('cod_programa', $cod_programa);
      }else{
        $this->vista->set('programa', $this->TPrograma->get($cod_programa));
      }
		
			$CANT_SEMESTRES = 2; #CANTIDAD DE SEMESTRES
			$this->vista->set('cantidad_semestres', $CANT_SEMESTRES);
			$this->vista->display();
    }

    /**
	 * Registrar programas y cursos
	 */
    function configurar() {
     //SOLO EL ADMINISTRADOR PUEDE MATRICULAR
     if(!is_super_admin_login())
       return $this->vista->acceso_restringido();

     require_once CARPETA_MODELOS_EXTRAS . "ConfiguraProgramas.php";
     $this->includeModel('TComponente');

     //TODO: actualizar el codigo del programa a matricular.
     $oConfig = new ConfiguraProgramas($this->params['cod_programa']);
     $this->vista->addJS('jquery.dataTable','jquery.multiselect');

     if(!empty($this->params['programa'])) {
      $oConfig->__cursos = $this->params['programa']['cursos'];
			$oConfig->cod_componentes = $this->params['programa']['cod_componentes'];
      if($oConfig->registrarCursos())
      	return redirect_to('cursos','index',array('cod_programa'=>$this->params['cod_programa']));
			else
				echo "LOS CURSOS NO PUDIERON SER CREADOS.";
     }else {
       $this->vista->set('oConfig',$oConfig);
       $this->vista->display();
     }
   }
  }
?>
