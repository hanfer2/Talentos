<?php
	/**
     * Clase AsistenciasController extendida de Controller
     */
	class AsistenciasController extends Controller{

		/**
		 * Constructor de la Clase AsistenciasController
		 */
		function __construct() {
			parent::__construct();
			$this->includeModel('TComponente','TClase', 'TEstudiante');
			$this->vista->setTitle('Asistencias');
		}

		/**
		 * Muestra las clases y su asistencia, segun curso y componenete especifico
		 */
		function clases(){
			if(isset($this->params['cod_curso'])){
				$clases = TSubgrupo::clases($this->params['cod_curso'], $this->params['cod_componente'], array('maxDate'=>date('Y-m-d')));
				$this->vista->set("clases", $clases);
				$this->vista->set('clasesRegistradas', TSubgrupo::clasesConAsistencias($this->params['cod_curso'], $this->params['cod_componente']));
			}
			$this->vista->display();
		}

		/**
		 * Listado de inasistencias
		 *
		 * Muestra el listado de inasistencias de un estudiante
		 */
		function view(){
			$this->vista->setTitle('Asistencia - Listado de Inasistencias');
			$this->vista->addJS('jquery.dataTable');
			if(isset($this->params['cedula'])){
				if(!canViewStudent($this->params['cedula']))
					return $this->vista->acceso_restringido();
				$inasistencias = TAsistencia::inasistencias(array('cedula'=>$this->params['cedula']));
				//$totalInasistencias = TClase::totalPorComponente(TEstudiante::curso($this->params['cedula'],null,'cod_grupo'));
				$this->vista->set('curso',TEstudiante::curso($this->params['cedula']));
				$this->vista->set('motivos', TMotivoInasistencia::motivos());
				$this->vista->set('nClasesReportadas', TAsistencia::clases($this->params['cedula'], array('operation'=>'count')));#Numero de clases reportadas
				$this->vista->set('inasistencias', $inasistencias);
				$this->vista->set('status', TEstado::nombre(TEstudiante::estado($this->params['cedula'])));
			}
			$this->vista->display();
		}

			/**
			 * Listado de inasistencias
			 *
			 * Muestra el listado de inasistencias por programa o por curso
			 */
		function general($params){
			if(!is_admin_login() && !is_coordinator_login())
				$this->vista->acceso_restringido();
			$this->vista->addJS('jquery.dataTable');
			$conditions = null;
			if(!is_blank($params['cod_programa'])){
				$conditions = array('cod_programa'=>$params['cod_programa']);
			}elseif(!is_blank($params['cod_curso'])){
				$conditions = array('cod_curso'=>$params['cod_curso']);				
			}
			if(!is_null($conditions)){
				$this->vista->set('inasistencias', TAsistencia::inasistencias($conditions));
				$this->vista->set('clasesAsistidas', TAsistencia::nClasesAsistidas($conditions));
				$this->vista->set('motivos', TMotivoInasistencia::motivosAgrupadosPorValidez());
			}
			$this->vista->display();

		}

		/**
		 * Registro de asistencias
		 *
		 * Permite registrar la asistencia de un estudiante de un grupo en una clase especifica
		 */
		function registrar(){
			$this->vista->setTitle("Asistencia - Registrar");
			$this->vista->addJS('jquery.dataTable');
			if(isset($this->params['cod_clase'])){
				$cod_curso = $this->params['cod_curso'];
				if($cod_curso == null){
					$cod_curso = TClase::cod_curso($this->params['cod_clase']);
					$cod_componente = TClase::cod_componente($this->params['cod_clase']);
					$this->vista->set('cod_curso', $cod_curso);
					$this->vista->set('cod_componente', $cod_componente);
				}
				$clase = TClase::get($this->params['cod_clase'], '*');
        $oSubgrupo = new TSubgrupo();
				$estudiantes = $oSubgrupo->inscritosActivos($cod_curso, array(" fecha_ingreso <='{$clase['fecha']}' "));
				$asistencias = TAsistencia::porEstudiante($this->params['cod_clase']);


				if($clase['updated_by'] != null){
					$clase['updated_by'] = TPersona::get(array('cod_interno'=>$clase['updated_by']), "fullname(".Config::get('TPersona').".*)");
				}

				$this->vista->set('asistencias', $asistencias);
				$this->vista->set("clase", $clase);
				$this->vista->set('estudiantes', $estudiantes);
				$this->vista->set('justificaciones', TMotivoInasistencia::all(array('select'=>'codigo, nombre')));
				$this->vista->set('estudiantesFlotantes', TEstudiante::flotantes());
				if(isset($this->params['u'])){
					$this->vista->set('alert_message',$this->params['u']?"Actualizaci&oacute;on Exitosa":"Actualizaci&oacute;n FALLIDA");
				}
			}
			$this->vista->display();
		}


        /**
         * Registra las asistencias de una clase
         */
		function save(){
			if(isset($this->params['asistencia'])){
				$asistencia = $this->params['asistencia'];
				 $ok = TClase::registrarAsistencia($this->params['clase'], $this->params['asistencia']);
				 redirect_to ('asistencias', 'registrar', array('cod_clase'=>$this->params['clase']['codigo'],'u'=>$ok));
			}
		}

        /**
         * Muestra el formato de asistencia
         */
		function formatos(){
			$this->vista->setTitle('Formatos de Asistencia');
			if(isset($this->params['cod_curso'])){
				$sql = "SELECT cedula, apellidos, nombres, nombre_grupo ".
							" FROM ".Config::get('TEstudiante','TGrupo') .
							" INNER JOIN ".Config::Get('TPersona') . " p USING (cod_interno, cedula)".
							" WHERE p.cod_estado = ".COD_ESTADO_ACTIVO . " AND ";
				if($this->params['cod_curso'] == '0')
					$sql .= "cod_programa = '{$this->params['cod_programa']}'";
				else
					$sql .= "cod_grupo = '{$this->params['cod_curso']}'";
				$cursos = DB::table_query($sql, 'nombre_grupo');
				$this->vista->set('cursos', $cursos);
			}
			$this->vista->display();
		}
	}
?>
