<?php

	if(is_student_login ())
	 return acceso_restringido ();

	/**
	 * Clase CursosController extendida de Controller
	 */
	class CursosEspecialesController extends Controller {

     /**
	 * Constructor de la Clase CursosController
	 */
	 function __construct() {
		parent::__construct();
    $this->vista->setTitle('Cursos');
		$this->TSubgrupo = new TSubgrupo();
		$this->TPrograma = new TPrograma();
	 }
   
   function view(){
     $this->vista->display();
   }

}
?>
