<?php
 
  class ConfiguraProgramas{
    var $__cursos = array(
      'A'=>array(
        '1'=>36,'2'=>36,'3'=>36,'4'=>36,'5'=>36,
				'6'=>35,'7'=>35,'8'=>35,'9'=>35,'10'=>35,'11'=>35 ),
      'B'=>array(
        '1'=>36,'2'=>36,'3'=>36,'4'=>36,'5'=>36,
        '6'=>36,'7'=>36,'8'=>36,'9'=>36,'10'=>36 ),
      'C'=>array(
        '1'=>36,'2'=>36,'3'=>36,'4'=>36,'5'=>36,
        '6'=>35,'7'=>35,'8'=>35,'9'=>35,'10'=>35,'11'=>35 ),
      'D'=>array(
        '1'=>36,'2'=>36,'3'=>36,'4'=>36,'5'=>36,
				'6'=>36,'7'=>36,'8'=>36,'9'=>36,'10'=>36 )
     );

		var $cod_componentes = array();

    var $__data = array();
    var $cod_programa;

    var $__cursoActual=array('grupo'=>'A','curso'=>'1');

    function ConfiguraProgramas($cod_programa){
			if(is_blank($cod_programa))
				trigger_error("ArgumentError: EL CODIGO DEL PROGRAMA NO PUEDE SER NULO", E_USER_ERROR);
      $this->cod_programa = $cod_programa;
    }

    function leerDatos($filename){
      $this->__data = CSV::load($filename);
    }

    function grupos(){
      return array_keys($this->__cursos);
    }

    function maxPorCursos(){
      return 11;
    }
		
		function consultarCupo($grupo, $curso){
			return $this->__cursos[$grupo][$curso];
		}

    function buscarCupo(){
      $cursoActual = $this->__cursoActual;
      $cuposEnCursoActual = $this->__cursos[$cursoActual['grupo']][$cursoActual['curso']];
      if($cuposEnCursoActual < 1)
        $this->__moverASiguienteCurso();
      return $this->__cursoActual;
    }

    function __moverASiguienteCurso(){
      $cursoActual = $this->__cursoActual;
      $siguienteCurso = ++$cursoActual['curso'];
      $siquienteGrupo = ++$cursoActual['grupo'];
      if(!isset($this->__cursos[$cursoActual['grupo']][$siguienteCurso])){
        if(!isset($this->__cursos[$siquienteGrupo]['1']))
          $this->__cursoActual = null;
        else
          $this->__cursoActual = array('grupo'=>$siquienteGrupo,'curso'=>'1');
      }else
        $this->__cursoActual['curso'] =$siguienteCurso;
      return $this->__cursoActual;
    }

    function __asignarCurso($estudiante){
      $curso = $this->buscarCupo();
      echo "Estudiante $estudiante Asignado en : {$curso['grupo']} {$curso['curso']}<br/>";
      --$this->__cursos[$curso['grupo']][$curso['curso']];
    }

		function registrarCursos(){
			$sql = "SELECT 1 FROM ".Config::get('TGrupo')." WHERE cod_programa = '{$this->cod_programa}' LIMIT 1";
			$cursosEnPrograma = DB::query($sql);

			if(!empty($cursosEnPrograma))
				return FALSE;
			$cod_curso = TSubgrupo::max();
			foreach($this->__cursos as $grupo=>$cursos){
				foreach($cursos as $curso=>$cupo){
					if(is_blank($cupo))
						continue;
					++$cod_curso ;
					TSubGrupo::crear(array('grupo'=>$grupo, 'subgrupo'=>$curso,'cod_programa'=>$this->cod_programa, 'codigo'=>$cod_curso));
					foreach($this->cod_componentes as $cod_componente)
						TSubgrupo::adicionarComponente($cod_curso, $cod_componente, 1);
				}
			}
			return true;
		}
		
    function poblarCursos(){
      $this->__data = range(1,750);// TEST
      foreach($this->__data as $estudiante){
        $this->__asignarCurso($estudiante);
      }
    }
  }
?>
