<?php
  require_once CARPETA_LIBS . "Smarty" . DS . "Smarty.class.php";

  class Vista extends Smarty {
    var $layout;
    var $extraHeaders = '';
    var $__extensionFile = 'tpl';
    var $current_controller = "";
    var $current_action = '';
    var $templateFolder = null;
    var $__baseTemplateDir = "";
    var $__flash = "";


    function Vista() {
      parent::Smarty();
      $this->_setup();
      $this->layout = "default";
    }
    
	 function _setup() {
		$this->template_dir = CARPETA_VISTAS;
		$this->compile_dir = SMARTY_DIR . DS . 'views' . DS . 'templates_c';
		$this->cache_dir = SMARTY_DIR . DS .'views' . DS . 'cache';
		$this->config_dir = SMARTY_DIR . DS. 'views' . DS . 'configs';
		$this->__baseTemplateDir = $this->template_dir;
	 }

    function setTitle($title) {
      $this->set('pageTitle', $title);
    }

    function addJS() {
      $paths = func_get_args();
      foreach ($paths as $path)
        $this->extraHeaders .= includeJS($path). "\n";
    }

    function addCSS($paths) {
      $paths = func_get_args();
      foreach ($paths as $path)
        $this->extraHeaders .= includeCSS($path). "\n";
    }

    function acceso_restringido() {
			header('HTTP/1.1 403 Forbidden');
      $this->show('acceso_restringido', null, array('layout'=>'clean'));
      exit();
    }

    function set($var, $value=null) {
      $this->assign($var, t($value));
    }
    
    function __chooseMinifiedScript($folder, $file, $extension){
    	$SUFFIX = 'min';
    	if(file_exists($folder."$file.$SUFFIX.".$extension))
    		return "$file.$SUFFIX";
    	return $file;
    }
    
    function __loadCustomJS(){
      $controllerJS = 'custom'. DS . $this->current_controller ;
      if(file_exists(CARPETA_JS . $controllerJS.".js")){
      	$file = $this->__chooseMinifiedScript(CARPETA_JS, $controllerJS, ".js");
        $this->addJS ($file);
      }
      $actionJS = 'custom'. DS . $this->current_controller."_".$this->current_action ;
      if($actionJS != $controllerJS && file_exists(CARPETA_JS . $actionJS.".js")){
       	$file = $this->__chooseMinifiedScript(CARPETA_JS, $actionJS, ".js");
        $this->addJS($file);
      }
    }
    
    function __loadCustomCSS(){
      $controllerCSS = 'custom'. DS . $this->current_controller;
      if(file_exists(CARPETA_CSS . $controllerCSS.".css")){
	      $file = $this->__chooseMinifiedScript(CARPETA_CSS, $controllerCSS, ".css");
        $this->addCSS ($file);
      }
      $actionCSS = 'custom'. DS . $this->current_controller . "_" . $this->current_action;
      if($actionCSS != $controllerCSS && file_exists(CARPETA_CSS . $actionCSS.".css")){
      	$file = $this->__chooseMinifiedScript(CARPETA_CSS, $actionCSS, ".css");
        $this->addCSS($file);
      }
    }
		
		function _isset($var){
			return isset($this->_tpl_vars[$var]);
		}
		
		function __addImplicitVars(){
			if($this->_isset('cedula') && class_exists('TPersona'))
				$this->set('nombre_persona', TPersona::nombre($this->_tpl_vars['cedula']));
			if($this->_isset('cod_prueba') && class_exists('ITipo'))
				$this->set('nombre_prueba', ITipo::nombre($this->_tpl_vars['cod_prueba']));
			if($this->_isset('cod_curso') && class_exists('TSubgrupo')){
				$this->set('nombre_curso', TSubgrupo::nombre($this->_tpl_vars['cod_curso']));
				if(!$this->_isset('cod_programa'))
					$this->set('cod_programa', TSubgrupo::programa($this->_tpl_vars['cod_curso']));
			}
			if($this->_isset('cod_programa') && class_exists('TPrograma'))
				$this->set('nombre_programa', TPrograma::nombre($this->_tpl_vars['cod_programa']));
			if($this->_isset('cod_componente') && class_exists('TComponente'))
				$this->set('nombre_componente', TComponente::nombre($this->_tpl_vars['cod_componente']));
				
			$this->set('is_admin_login', is_admin_login());
		}
    
    function setController($controller){
      $controller = lower($controller);
      if(is_blank($this->pageTitle))
        $this->pageTitle = $controller;
      $this->current_controller = $controller;
      $this->template_dir = $this->__baseTemplateDir . $controller ;
    }
		
		function notify($message, $tipo="NOTICE"){
				$this->__flash = $message;
		}
		
		function show($templateName, $vars=array(), $options=array()){
			$oVista = new Vista();
			$oVista->set($vars);
			$oVista->template_dir = CARPETA_VISTAS . '_public';
			if(isset($options['layout']))
				$oVista->layout = $options['layout'];
			if(file_exists(CARPETA_CSS.$templateName.".css"))
				$oVista->addCSS($templateName);
			$oVista->display('pages/'.$templateName);
		}
		
		function includeParams(){
			$params = params();
			foreach($params as $k=>$param){
				if(is_array($param)){
					$subkey = key($param);
					$this->set($k."_".$subkey, $param[$subkey]);
				}
				else
					$this->set($k, $param);
			}
			return $params;
			
		}

    function display($__templateName=null) {
      if (is_blank($__templateName))
        $__templateName = $this->current_action;
      if (!endsWith($__templateName, ".$this->__extensionFile"))
        $__templateName .= ".".$this->__extensionFile;
				
			$controllerFolder = any($this->templateFolder,$this->current_controller);
			$templateFile = $__templateName;
      
			if(is_blank($controllerFolder))
				$controllerFolder = '_public';
      if (!file_exists(CARPETA_VISTAS. $controllerFolder . DS. $templateFile)) {
				$this->setTitle('Recurso No Hallado');
				$message = MarkDown("Plantilla **".substr($templateFile,0,-4)."** no hallada en **$controllerFolder**");
      	$this->show('404', array("message"=>$message));
      	return;
      }
      $this->includeParams();

			$this->__addImplicitVars();

			$this->config_load("conf.ini");
			$this->compile_id = $controllerFolder;
			$this->assign("__flash", $this->__flash);
      
      // IF NOT LAYOUT
      if ($this->layout === FALSE || (is_xhr() && $this->layout !== FALSE )){
				return parent::display($__templateName);
      }else {
        $this->__loadCustomCSS();
        $this->__loadCustomJS();
        $this->assign("content_for_layout", "..".DS.$controllerFolder. DS.$__templateName);
        $this->assign("__extraHeaders", $this->extraHeaders);
				$path = ".." . DS . "_layouts" . DS . $this->layout . "." . $this->__extensionFile;
        
        $siat_menu = MenuFactory::getMenu();
        $this->assign('siat_menu', $siat_menu);
        $this->register_function('include_menu', 'smarty_function_include_menu');
        return parent::display($path);
      }
    }
    
    function _display($tpl){
      return parent::display($tpl);
    }

  }

?>
