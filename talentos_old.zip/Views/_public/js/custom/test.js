$(function(){
	$("#ajax-test").click(function(){
		$.get(url_for("acceso_restringido"))
	})
})
