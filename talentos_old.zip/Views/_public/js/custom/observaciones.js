Observaciones = {
	checkNew: function(){
		$$("form-nuevaObservacion").validity(function(){
			$("input.required, textarea").require()
		})
	}
}

$(function(){
	$$("bt-listadoDeObservaciones").click(function(){
		$(".ajax-response").ajax_img()
		$.get(url_for(), {"cod_programa":$F("#cod_programa")}, function(html){
			$(".ajax-response").html(html)
		})
	})
	
	$(".link-eliminarObservacion").live("click", function(){
		var cod_observacion = this.id.substring("link-eliminarObservacion-".length)
		jConfirm("Está seguro de eliminar esta observacion?", "Confirmacion", function(r){
			if(r)
				$.post(url_for('delete'), {"cod_observacion":cod_observacion}, function (){$$("observacion-"+cod_observacion).slideUp(function(){$(this).remove()})})
			})
		
		return false;
	})
	
	$$("bt-listadoDeObservacionesIndividual").click(function(){
		cedula = $F("#input-buscarPorCedula")
		if(cedula.length > 3 && !isNaN(cedula)){
			$(".ajax-request").ajax_img()
			$.post(url_for('view'), {"cedula":cedula}, function(html){
				$(".ajax-request").html(html)
			})
		}
	})
	
	$$("link-toggleNuevaObservacion").live('click', function(){
		$$("wrapper-form-nuevaObservacion").slideToggle()
	})
	
	Observaciones.checkNew()
	$(".ajax-request").ajaxSuccess(function(){
		Observaciones.checkNew()
	})
})
