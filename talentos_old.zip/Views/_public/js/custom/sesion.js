$(function(){
	$("#popup-notificaciones").dialog({
		'modal':true, "title":'Alerta!!!', "width":550,
		'dialogClass':'ui-alert-dialog ui-state-error'
	})// fin dialog
})
