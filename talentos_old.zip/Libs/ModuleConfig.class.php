<?php
	
	class ModuleConfig{
		
		var $_settings  = array();
    var $_controller = null;
    
		function ModuleConfig($controller){
      $this->_controller = $controller;
      $this->_load();
		}
    
    function getController(){
      return $_controller();
    }
    
    function _load()
    {
      $path = CARPETA_CONFIG . 'modules/'. $this->_controller . '/';
      
      if( ! is_dir($path) )
        return false;
      
      $settingsFile = $path . 'settings.ini';
      if( ! file_exists($settingsFile) )
        return false;
      $this->_settings = parse_ini_file($settingsFile, true);
    }
    
    function get($action, $setting){
      if($this->_settings == null)
        return false;
      $actionSettings = $this->_settings[$action];
      $defaultSettings = $this->_settings['default'];
      
      if($actionSettings == null){
        if($defaultSettings == null)
          return false;
        else
          $actionSettings = $defaultSettings;
      }
      
      return $actionSettings[$setting];
    }
    
    function isActionUnderConstruction($action){
      return $this->get($action, 'under_construction');
    }
    
    function hasCredential($action){
      $cedulas_autorizadas = $this->get($action, 'auth_cedulas');
      $roles_autorizados = $this->get($action, 'auth_roles');
      
      if( $cedulas_autorizadas == null && $roles_autorizados == null)
        return true;
        
      $roles_autorizados = arrayize(explode(',',$roles_autorizados));
      foreach($roles_autorizados as $rol){
        $rol = trim($rol);
        if(defined($rol))
          $rol = constant($rol);
        if(is_user_login($rol))
          return true;
      }
      
      $cedulas_autorizadas = arrayize(explode(',',$cedulas_autorizadas));
      foreach($cedulas_autorizadas as $cedula){
        $cedula = trim($cedula);
        if(is_logged_cedula($cedula))
          return true;
      }
      return false;
    }
		
	}
?>
