<?php
/**
*clase  cargar el archivo que es llamado dando su nombre como parametro de entrada
*teniendo una funcion  para cada ruta donde se encuentra el archivo a ser llamada.
*/
	class AppLoader{
		

   /**
*valida si el archivo a cargar existe en la ruta que se especifico dada por las demas funciones, si 
*es es asi lo carga en caso contrario,hace nada
@param String $file
@return Boolean
*/
    function _load($file){
      if(file_exists ($file)){
        require_once($file);
        return true;
      }

      return false;
    }
    
 /**
*la llama de cada metodo devuelve la ruta del archivo, llamando a una constante que esta definida en paths.php.
*concatenado con el nombre que se ingreso como parametro a la funcion y con la extension del archivo
*/

/**
* devuelve la ruta de el archivos que estan en CARPETA_LIBS definidad en el paths.php
@param String $filename
@return String 
*/
		function load($filename){
      $filepath = CARPETA_LIBS.$filename.'.class.php';
      AppLoader::_load($filepath);
    }

/**
*devuelve la ruta de el archivos que estan en CARPETA_HELPERS definidad en el paths.php
@param String $filename
@return String 
*/
    function load_helper($filename){
      $filepath = CARPETA_HELPERS.$filename.'Helper.php';
      AppLoader::_load($filepath);
    }
    
/**
*devuelve la ruta de el archivos que estan en CARPETA_CONFIG definidad en el paths.php
@param String $filename
@return String 
*/
    function load_config($filename){
      $filepath = CARPETA_CONFIG .$filename. '.php';
      AppLoader::_load($filepath);
    }
    
/**
*devuelve el nombre del archivo con la extension .php
@param String $file
@return String 
*/
    function load_file($file){
      AppLoader::_load($file . '.php');
    }
    
/**
*devuelve la ruta de el archivo que estan en CARPETA_MODELOS definidad en el paths.php
@param String $model
@return String 
*/
    function load_model($model){
      $filepath = CARPETA_MODELOS . $model . '.inc';
      AppLoader::_load($filepath);
    }
    
	}
?>
