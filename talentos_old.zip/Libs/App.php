<?php
	class App{
    
    $_Smarty = null;
    
    function &getInstance() {
			static $config = null;
			if ($config === null)
				$config = new App();
			return $config;
		}
    
    function set($param, $value){
      $param = "_".$param;
      $app = App::getInstance();
      $app->$param = $value;
    }
    
		function getSmarty()
    {
        return App::getInstance()->_Smarty;
    }
	}
?>
