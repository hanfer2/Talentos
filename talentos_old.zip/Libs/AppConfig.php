<?php
	
	class AppConfig{
		
		
		function AppConfig(){
			$this->db = DB::instance();
			$this->tablename = 'sys_configuraciones';
		}
		

  /**
   * Singleton
   *
   * 
   * @param
   * @return AppConfig
   */
		function instance(){
			static $AppConfig = null;
			if ($AppConfig === null)
				$AppConfig = new AppConfig();
			return $AppConfig;
		}
		
/**
*retorna el numero de items a mostrar en los autocomplet
@param $nombre
@return int
*/
		function get($nombre){
			$nombre = q($nombre);
			$sql = "SELECT valor FROM ".$this->tablename. " WHERE '$nombre' = upper(nombre)";
			return $this->db->fetchOne($sql);
		}
		
/**

@param $nombre
@param $valor
@return int
*/
		function set($nombre, $valor){
			$valor = q($valor);/*nos se que es q()*/
			$nombre = q($nombre);
			$sql = "UPDATE ".$this->tablename;
			if($valor === FALSE)
				$sql .=" SET valor = FALSE ";
			else if($valor === TRUE)
				$sql .=" SET valor = TRUE ";
			else if($valor == null)
				$sql .=" SET valor = NULL ";
			else
			 $sql .=" SET valor = '$valor' ";
			$sql .=" WHERE upper(nombre) = '$nombre'";
			return $this->db->fetchOne($sql);
		}
	}

?>
