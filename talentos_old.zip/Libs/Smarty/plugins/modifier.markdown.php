<?php


### Smarty Modifier Interface ###

function smarty_modifier_markdown($text) {
	return Markdown($text);
}
?>
