<?php
function smarty_function_include_template($params, &$smarty)
{
		$file = $params['file'];
		if(!endsWith($file,".tpl"))
			$file .= ".tpl";
		unset($params['file']);
		$smarty->assign($params);
		return $smarty->fetch("../_shared/$file");
}
?>
