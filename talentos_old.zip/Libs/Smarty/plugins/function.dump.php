<?php 
  function smarty_function_dump($params){
    debug($params['var']);
  }
?>
