<?php

AppLoader::load('menu/Menu');

class CoordinadorMenu extends Menu{
    function CoordinadorMenu(){
      parent::Menu();
    }
  }
  
?>
