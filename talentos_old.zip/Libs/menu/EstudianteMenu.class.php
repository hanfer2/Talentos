<?php

AppLoader::load('menu/Menu');

class EstudianteMenu extends Menu{

		function EstudianteMenu()
    {
    }
    
  }
?>
