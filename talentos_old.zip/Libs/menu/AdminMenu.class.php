<?php

AppLoader::load('menu/Menu');

  class AdminMenu extends Menu{
    
    function AdminMenu(){
      parent::Menu();
    }
    
  }
  
?>
