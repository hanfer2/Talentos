<?php

AppLoader::load('menu/Menu');

class DocenteMenu extends Menu{
    function DocenteMenu(){
      parent::Menu();
    }
  }
?>
