<?php

AppLoader::load('menu/Menu');

class VisitanteMenu extends Menu{
    function VisitanteMenu(){
      parent::Menu();
    }
  }
?>
