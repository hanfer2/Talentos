<?php

/**
*define que controladores y que vista mostrar,que opciones habilitar en la vista segun el usuario que acceda al sistema
*/
	
	class AppDispatcher{
    
    var $controllerParam = "controlador";
    var $actionParam = "accion";
    var $defaultController = "sesion";
    var $defaultAction = "index";
    var $privateActionPrefix = "_";
		
		function AppDispatcher(){
			$this->init();
      $this->_getParams();
		}
		
    function init(){
      header_iso();
      setlocale(LC_ALL, "es_Es");/*? esto es para definir el idioma con que se cargara la informacion ??*/
    }
    
    function _getParams(){
      $this->controller = $_GET[$this->controllerParam];
      if($this->controller == null)
        $this->controller = $this->defaultController;
        
      if(!empty($_GET[$this->actionParam]))
        $this->action = $_GET[$this->actionParam];
      else
        $this->action = $this->defaultAction;
        
      $this->_define_vars();
    }
    

    function _define_vars(){
      $this->controllerName = camelizeUS($this->controller)."Controller";

      $this->controllerPath = CARPETA_CONTROLADORES . $this->controllerName .".php";
      
      $this->is_private_action = startsWith($this->action,$this->privateActionPrefix);
    }
    
    function define_unlogged_zone(){
      if(!is_user_login() && !is_path_for_unlogged($this->controller, $this->action) ){
         require_once CARPETA_CONTROLADORES . 'Controller.php';  
         /*
          * estaba haciendo referencia a un archivo que no se encuentra en esa ruta
          * */
         //require_once('./lib/Controller.class.php');  
         require_once(CARPETA_CONTROLADORES."SesionController.php");
         $sesion = new SesionController();
         $sesion->_displayLoginPage($_SERVER['REQUEST_URI']);
         return false;
      }
      return true;
    }
    
    function show404($msg){
      header("HTTP/1.0 404 Not Found");
      Vista::show('404',array('message'=>$msg, 'pageTitle'=>"Recurso No Hallado"), array('layout'=>'clean'));
      return false;
    } 
    
    function showUnderConstruction(){
      Vista::show('under_construction',null, array('layout'=>'clean'));
      return false;
    }
    
    function showAccessDenied(){
      header("HTTP/1.0 403 Forbidden");
      Vista::show('acceso_restringido',null, array('layout'=>'clean'));
      return false;
    }
    
    function invokeController(){
      if($this->is_private_action)
          return redirect_to("sesion","acceso_restringido");
      if(is_file($this->controllerPath)){
        require_once CARPETA_CONTROLADORES . 'Controller.php';
        require $this->controllerPath;
        
      }else{
        return AppDispatcher::show404("Controlador {$this->controller} ({$this->controllerPath}) no hallado");
      }
      
      if(is_callable(array($this->controllerName, $this->action))== false)
      {
        return AppDispatcher::show404("La accion {$this->controller}::{$this->action} no esta definida");
      }
      else
      {
        AppLoader::load_config('config');
        
        $o = new $this->controllerName();
        if(is_blank($o->vista->folder_view)){
            $o->vista->setController(lower($this->controller));
        }
        $accion = $this->action;
        $o->vista->current_action = $accion;
        $o->$accion(params());
      }
      
    }
    
    function verify_request(){
      if(! $this->define_unlogged_zone() )
        return false;
      if($this->is_private_action){
          AppDispatcher::showAccessDenied();
          return false;
      }
      
      if(is_file($this->controllerPath)){
        require_once CARPETA_CONTROLADORES . 'Controller.php';
        /*
          * estaba haciendo referencia a un archivo que no se encuentra en esa ruta
          * */
        //require_once('./lib/Controller.class.php');  
        require_once $this->controllerPath;
        
      }else{
        AppDispatcher::show404("Controlador {$this->controller} ({$this->controllerPath}) no hallado");
        return false;
      }
      
      if(is_callable(array($this->controllerName, $this->action))== false){
        AppDispatcher::show404("La accion {$this->controller}::{$this->action} no esta definida");
        return false;
      }
      return true;
    }
    
    function executePreFilter($controller){
      $preFilter = 'pre'.ucfirst($this->action);
      $rs = true;
      if(is_callable(array($this->controllerName, $preFilter))){
        $rs = $o->$prefilter(params());
        if($rs === NULL)
          return true;
        return $rs;
      }else
        return true;
    }
    
    function loadControllerConfig(){
      $this->moduleConfig = new ModuleConfig($this->controller);
    }
    
    
    function validateCredential(){
      if(is_root_login())
        return true;
      $hasCredential = $this->moduleConfig->hasCredential($this->action);
      return $hasCredential;
    }
    
    function checkIsActionUnderConstruction(){
      return $this->moduleConfig->isActionUnderConstruction($this->action);
    }
    
    function dispatch(){
      if($this->verify_request()){
        AppLoader::load_config('config');
        
        $o = new $this->controllerName();
        
        if(is_blank($o->vista->folder_view)){
            $o->vista->setController(lower($this->controller));
        }
        
        $this->loadControllerConfig();
        $isUnderConstruction = $this->checkIsActionUnderConstruction();
        
        
        $hasCredential = $this->validateCredential();
        if(! $hasCredential){
          AppDispatcher::showAccessDenied();
          return false;
        }
        
        $ok = $this->executePreFilter($o);
        if($ok){
          $accion = $this->action;
          $o->vista->current_action = $accion;
          if($isUnderConstruction)
            $o->under_construction();
          $o->$accion(params());
        }
      }
      
    }

	}

?>
