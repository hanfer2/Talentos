clear
cd ../../Views/_public/

if [[ $# -gt 0 ]]; then
	echo "================="
	for arg in "$@"
	do
		file=${arg%.*s}
		type=${file:0:3}
		file=${file:4}
		echo -n "Compressing.... $file.$type"
		java -jar yuicompressor.jar "$type/$file.$type" -o "$type/$file.min.$type"	
		echo "........ [OK]"
	done
	echo "------------------"
	echo "All $# files are compressed"
	echo ""
else
	for type in 'js' 'css'
	do
		echo "Compressing $type"
		echo "================="
		regexp="min\.$type$"
		nFiles=0
		for file in `ls $type/*.$type`
		do
			if [[ !("$file"=~$regexp) ]]; then 
				filename=${file%.*s}
				printf "Compressing.... $file"
				java -jar tools/yuicompressor.jar "..$type/$file" -o "$type/$filename.min.$type"		
				printf "....... [OK]\n"
				let "nFiles += 1";
			else
				echo "+$file"
				if  test "r" =~ ".ww" 
				then
					echo "t";
				else
					echo "f"
				fi
				echo -e "$regexp"
			fi
		done
		echo "------------------"
		echo "All $nFiles $type files are compressed"
		echo ""
	done
fi
