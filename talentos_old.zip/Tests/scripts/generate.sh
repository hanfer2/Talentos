#! /bin/bash

if [[ "$#" -lt 1 ]]; then
echo -e "[ERROR] Es requerido el nombre del controlador";
exit 1;
fi;

declare controllerName;
controllerName=$1;

#VARIABLE DECLARATIONS
rootPath="../../";
declare -r rootPath;
controllersPath="${rootPath}Controllers/";
declare -r controllersPath;
viewsPath="${rootPath}Views/";
declare -r viewsPath;
cssPath="${viewsPath}_public/css/custom";
declare -r cssPath;
jsPath="${viewsPath}_public/js/custom";
declare -r jsPath;

controllerFile="${controllersPath}${controllerName}Controller.php";
viewFolder="${viewsPath}${controllerName}"
cssFile="${cssPath}${controllerName}.css"
jsFile="${jsPath}${controllerName}.js"

if [ $2 == "-d" ]; then
	rm -r $controllerFile $viewFolder $cssFile $jsFile;
else
	(
	cat<<CONTROLLER_TEXT
<?php
	/**
	 *
	 */
	Class ${controllerName}Controller extends TBase { 
		function __construct(){
			parent::__construct();
		}
		
		function index(){
		}
	}
?>
CONTROLLER_TEXT
)> $controllerFile;

	if [ -f "$controllerFile" ]; then
		chmod 755 $controllerFile;
		echo -e "Controlador '$controllerName' Creado";
	else
		echo -e "Error Creando Archivo";
	fi

	#CREACION DE DIRECTORIO DE VISTAS
	mkdir $viewFolder;
	echo -e "Directorio de Vistas '$controllerName' creado";
	#CREACION DE CSS
	touch $cssFile;
	echo -e "Archivo CSS '$controllerName'.css creado";
	#CREACION DE JS
	touch $jsFile;
	echo -e "Archivo JS '$controllerName'.js creado";
fi
