#! /bin/bash
#
# Esta script genera un archivo comprimido (backup)
# de todos los archivos fuentes de la aplicacion

if [ "$1" = "clean" ]; then
	rm -vf ../../talentos_*.tar.gz
	echo -e "Se eliminar todos las copias de seguridad de la aplicacion"
	exit 0
fi

today=`date "+%Y-%m-%d_%H-%M-%S"`
filename="talentos_$today.tar.gz"  #nombre del archivo: talentos_<fecha_hora actual>.tar.gz

cd ../../
echo -e"backup.sh: Comenzando tarea de compresion de archivos..."

tar czvf ./Tests/backups/$filename index.html Config Controllers Helpers Libs Models Tests Views .htaccess \
		--exclude='Libs/Smarty/views/templates_c/*' --exclude='Libs/Smarty/views/cache/*' --exclude='Tests/backups/*' #carpetas a excluir
ok=$?
if [ "$ok" != "0" ]; then
	echo -e "[FATAL ERROR] Hubo un error"
	exit $ok
else
	echo -e "==========="
	echo -e "Sistema comprimido en $filename"
	exit 0
fi

