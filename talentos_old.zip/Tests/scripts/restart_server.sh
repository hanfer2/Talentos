echo `apachectl restart`
